#include "RemoteCDBrowse.hpp"

// constructor
RemoteCDBrowse::RemoteCDBrowse () : mActiveFolderNumber_ ( -1 ) , mItemIndex_ ( 0 ) 
{
    // create cache and keep caching all the requests if we want to disable builder by default other constructor of cache can be used
    cache_ = make_shared < RemoteCDCache > ( false ) ;

    PRESEVENT_SUBSCRIBE ( cacheUpdate, EVENT_CACHE_FOLDER_UPDATE, &RemoteCDBrowse::onCacheUpdate, _1, _2 ) ;
    PRESEVENT_SUBSCRIBE ( activeFolder, EVENT_PLAYCONTROL_ACTIVEFOLDER_STATUS, &RemoteCDBrowse::ActiveFolderInfo, _1 ) ;

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__ ) ;
}

/*****   EXTERN calls from RemoteCDManager etc,.   *****/
void RemoteCDBrowse::getFolderName ( short folderNumber, int nameLength, FolderRequestedData::eCutNameType cutName )
{
    if ( cache_-> isAvailable ( folderNumber ) )
    {
        PRESEVENT_PUBLISH ( getFolderNameStatus, EVENT_BROWSECONTROL_GETFOLDERNAME_STATUS, folderNumber, cache_-> getData ( folderNumber )-> getName () )
    }
    else
    {
        // data not available in cache, push the client request into the queue and request for the data to the player
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d entry FolderNumber %d was not cached so getting it from the player", __FUNCTION__, __LINE__, folderNumber ) ;
        RemoteCDManager::getInstance ()-> requestFolderName ( folderNumber, nameLength, cutName ) ;
    }
}

void RemoteCDBrowse::getBrowseInfo ( FolderRequest request )
{
    //LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d browse request <%d,%d,%d>", __FUNCTION__, __LINE__, request-> getNumber (), request-> getStartIndex (), request-> getCount () ) ;

   // if ( cache_-> isAvailable ( request-> getNumber (), request-> getStartIndex (), request-> getCount () ) )    processRequest ( request ) ;
   // else
   // {
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "FolderRequest <%d,%d%d> was not cached so getting it from the player", request-> getNumber (), request-> getStartIndex (), request-> getCount () ) ;

        // data not available in cache, push the client request into the queue and request for the data to the player
     //   requestList_. push_back ( request ) ;
        RemoteCDManager::getInstance ()-> requestFolder ( request-> getNumber (), request-> getStartIndex (), request-> getCount () ) ;
   // }
}


void RemoteCDBrowse::getFolderCount ( short FolderNumber)
{
    //Folder response = nullptr;
    //short TotalCount  = 0;
    //if ( cache_->isAvailable ( FolderNumber ) )  
      //   {
        //     response = cache_->getData ( FolderNumber );
          //  TotalCount =  response->getTotalItemCount();
            //PRESEVENT_PUBLISH ( browseTotalCount , EVENT_BROWSECONTROL_TOTAL_FOLDER_COUNT, TotalCount  ) ;
             //LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <TotalCount: %d>", __FUNCTION__, __LINE__, TotalCount ) ; 
         //}
    //else
      //   {
        //     LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <RequestFolder: %d>", __FUNCTION__, __LINE__, FolderNumber ) ; 
             RemoteCDManager::getInstance ()-> requestFolder ( FolderNumber , 0 , 1 ) ;
         //}
}

// cache notification upon cache update
void RemoteCDBrowse::onCacheUpdate ( Folder folder, bool success )
{
    bool processed = false ;

    // see if we have any requests from client 
    if ( ! requestList_. empty () )    processed = processRequest ( requestList_. front () ) ;

    else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d no request yet from the client maybe we are building the cache with the builder", __FUNCTION__, __LINE__ ) ;   

    // if processed the request remove from the queue list of requests
    if ( processed )  requestList_. pop_front () ;

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d success %d processed %d", __FUNCTION__, __LINE__, success, processed ) ;
}

/*****   utilities/ helpers   *****/

bool RemoteCDBrowse::processRequest ( FolderRequest request )
{
    Folder response = nullptr, cached = nullptr ;

    if ( cache_-> isAvailable ( request-> getNumber (), request-> getStartIndex (), request-> getCount () ) )    cached = cache_-> getData ( request-> getNumber () ) ;
    if ( cached )
    {
        // get current folder or its parent based on the request from the client
        response = applyRequestedRules ( request, ( request-> getFolderContent () == FolderRequestedData::eFolderContent::eRequestedFolder )? cached : cache_-> getData ( cached-> getParent () ) ) ;
        
        // publish data to client
        PRESEVENT_PUBLISH ( browseStatus, EVENT_BROWSECONTROL_BROWSEINFO_STATUS, response, true ) ;
    }
    else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Client requested folder %d data not yet arrived from player", __FUNCTION__, __LINE__, request-> getNumber () ) ;

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Client requested folder %d data %s sent", __FUNCTION__, __LINE__, request-> getNumber (), ( cached )? "" : "not" ) ;

    return ( cached != nullptr ) ;
}

Folder RemoteCDBrowse::applyRequestedRules ( FolderRequest request, Folder folder )
{
    // make a local copy of the data
    Folder response = make_shared < FolderData > ( folder-> getNumber (), folder-> getParent (), getInterestedName ( folder-> getName (), request-> getCutType (), request-> getItemNameLen () ) ) ;
    response-> setTotalItems ( folder-> getItemsList () . size () ) ;
    

    
    // takes care of interested items loop i.e., startIndex & numberOfItems that client requested
    for ( auto item : folder-> getItemsList ())
    {
        // now copy individual items of the folder after applying client rules on the name etc,.

            Item responseItem = make_shared < ItemData > () ;
 
            responseItem-> setIndex ( item-> getIndex () ) ;
            responseItem-> setName  ( getInterestedName ( item-> getName (), request-> getCutType (), request-> getItemNameLen () ) ) ;
            responseItem-> setType  ( item-> getType () ) ;
            responseItem-> setNumber ( item-> getNumber () ) ;

            response-> addItem ( responseItem ) ;
            
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  Added Items : < name : %s , itemType : %d >  ", __FUNCTION__, __LINE__, responseItem-> getName ().c_str() , responseItem -> getType ()  ) ;
 
    }

    return response ;
}

// applies the rules requested by the client for the item name, 2 rules currently cutName & nameLength, returns the resultant name after
string RemoteCDBrowse::getInterestedName ( string actualName, FolderRequestedData::eCutNameType cutType, short requestedLength )
{
    int start = 0, interestedLength = ( requestedLength > ( int ) actualName. length () )? actualName. length () : requestedLength ;
    
    switch ( cutType )
    {
        case FolderRequestedData::eCutNameType::eNone :
        case FolderRequestedData::eCutNameType::eHead :
            // start is 0 for these and nothing much to change here in terms of length as above interestedLength would take care of the job for us
            break ;
        case FolderRequestedData::eCutNameType::eTail :
            start = actualName. length () - interestedLength ;
            break ;
        case FolderRequestedData::eCutNameType::eThreeFourthHead : // 3/4th of the name for the begining take catre if this 3/4th is not exceeding the interestedLength if so curtial it
            interestedLength = ( ( int ) ( 0.75 * actualName. length () ) > interestedLength ) ? interestedLength : ( int ) ( 0.75 * actualName. length () ) ;
            break ;
        case FolderRequestedData::eCutNameType::eOneFourthTail :   // 1/4th of the name from the end
            interestedLength = ( ( int ) ( 0.25 * actualName. length () ) > interestedLength ) ? interestedLength : ( int ) ( 0.25 * actualName. length () ) ;
            start = actualName. length () - interestedLength ;
            break ;
    }
    // remove this print after initial tests
    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d retval %s start %d interestedLength %d", __FUNCTION__, __LINE__, actualName. substr ( start, interestedLength ). c_str (), start, interestedLength ) ;
    return actualName. substr ( start, interestedLength ) ;
}


void RemoteCDBrowse::ActiveFolderInfo ( CDActiveFolder  mCDActiveFolder_)
{
        LOG_INFO(LOG_CONTEXT_RCD_PLUGIN, "%s %d", __FUNCTION__ , __LINE__);


    mItemIndex_         = ( mCDActiveFolder_ . path . begin() ) -> second ;

    LOG_INFO(LOG_CONTEXT_RCD_PLUGIN, "%s %d < ActivefolderNumber : %d, itemIndex: %d >", __FUNCTION__ , __LINE__, mActiveFolderNumber_, mItemIndex_ );

    for ( auto it : mCDActiveFolder_.path )
    {
        LOG_INFO(LOG_CONTEXT_RCD_PLUGIN, "%s %d < folderNumber : %d, itemIndex: %d >", __FUNCTION__ , __LINE__, it.first , it.second );

    }

    short mFolderCount_ = ( mCDActiveFolder_ . summary . begin() ) -> second ;

    short mFileCount_ =   ( mCDActiveFolder_ . summary . begin() + 1 ) -> second ;

    for ( auto it : mCDActiveFolder_.summary )
    {
       LOG_INFO(LOG_CONTEXT_RCD_PLUGIN, "%s %d < itemType : %d, itemCount: %d >",      __FUNCTION__ , __LINE__,    it.first , it.second );

    }


    if ( mActiveFolderNumber_ != ( mCDActiveFolder_ . path . begin() ) -> first   )
    {

    mActiveFolderNumber_ = ( mCDActiveFolder_ . path . begin() ) -> first ;

    LOG_INFO(LOG_CONTEXT_RCD_PLUGIN, "%s %d Send BrowseRequest : < ActivefolderNumber: %d , totalItem: %d,  >",      __FUNCTION__ , __LINE__, mActiveFolderNumber_,    ( mFolderCount_ + mFileCount_ )  );
    
    
     LOG_INFO(LOG_CONTEXT_RCD_PLUGIN, "%s %d Send FolderName request ",      __FUNCTION__ , __LINE__ );
    
  //   RemoteCDManager::getInstance ()-> requestFolderName ( mActiveFolderNumber_, 20 ) ;
  //   RemoteCDManager::getInstance ()-> requestFolder ( mActiveFolderNumber_ , 0 , ( mFolderCount_ + mFileCount_ ) >= 16 ? 16 :  ( mFolderCount_ + mFileCount_ )  ) ;
   
   // this->getFolderName ( mActiveFolderNumber_, 20, FolderRequestedData::eHead );

//    FolderRequest mFolderRequest = make_shared <FolderRequestedData> ( mActiveFolderNumber_, 0, ( mFolderCount_ + mFileCount_ ) >= 20 ? 20 : ( mFolderCount_ + mFileCount_ ) ,  FolderRequestedData::eHead , MAX_ITEM_NAME_LENGTH, FolderRequestedData::eRequestedFolder );

  //   getBrowseInfo(mFolderRequest);

    }
}

// destructor
RemoteCDBrowse::~RemoteCDBrowse ()
{
    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Browser destroyed client requested list is %s empty", __FUNCTION__, __LINE__, ( requestList_. empty () )? "" : "not" ) ;
}

