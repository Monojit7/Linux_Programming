#include "RemoteCDLog.hpp"

// initialize all the contexts (class / modules) for which the logs needs to be captured, future class/ modules shall be added here.
// add the entries in ascending order of the key and match it with the enum eRemoteCDLogContexts (in the header file) for the log contextId
RemoteCDLog::RemoteCDLog ()
{
    logContextIdsNamesMap_ =
    {
        { "BROW",   "RemoteCDBrowser"        },
        { "CACB",   "RemoteCDCacheBuilder"   },
        { "CACE",   "RemoteCDCache"          },
        { "CDTP", 	"RemoteCDTP"             },
        { "MGR",	"RemoteCDManager" 		 },	
        { "PCTR",   "RemoteCDPlayControls"   }
    };
}

// registers the app, log level.
int RemoteCDLog::init ( )
{
	// register our application/ component with the dlt daemon.
	dlt_register_app ( APP_COMPONENT_ID, APP_COMPONENT_NAME ) ;
    	
	int dltIndex = 0 ;	
	for ( auto const &appContext : logContextIdsNamesMap_ )
    {
		dlt_register_context ( &dltData_ [ dltIndex++ ]. context, appContext. first. c_str(), appContext. second. c_str () ) ;
    }
	
    //set logger in verbose mode
    dlt_verbose_mode () ;
	
	return 0 ; // i.e., DLT_RETURN_OK.
}

int RemoteCDLog::write ( eRemoteCDLogContexts contextId, LogLevelType logLevel, const char *textFormat, ...)
{
	char buffer [LOG_MSG_MAXSIZE] ;
	
	// push variable arguments into buffer which is written into log.
	va_list vargs ;
	va_start ( vargs, textFormat ) ;
	vsnprintf (buffer, LOG_MSG_MAXSIZE, textFormat, vargs) ;
	va_end ( vargs ) ;

	if ( dlt_user_log_write_start ( &dltData_ [ contextId ]. context, &dltData_ [ contextId ]. contextdata, static_cast < DltLogLevelType > (logLevel) ) )
    {
        dlt_user_log_write_string(&dltData_ [ contextId ].contextdata, buffer ) ;
        dlt_user_log_write_finish(&dltData_ [ contextId ].contextdata ) ;
    }

	return 0 ; // i.e., DLT_RETURN_OK.
}

RemoteCDLog cdLog ;
