
#include "RemoteCDTP.hpp"
#include <string>
#include <locale>
#include <codecvt>
#include <unistd.h>
#include <cstring>
#include <cwchar>
#include <sstream>
#include <vector>



using namespace placeholders ;

// class members instantiation
condition_variable    RemoteCDTP::cv_ ;
mutex                 RemoteCDTP::sync_ ;
queue < tpData >      RemoteCDTP::messages_ ;

CDNowPlaying   nowPlayInfo ;

// constructor
RemoteCDTP::RemoteCDTP ( ) : stopped_ ( false )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__ ) ;
    
    
    // currently all data comes in canId - 0x2A6, if any new canId gets added in future update it here
    canIds_ = { CD_RDISP_WORD_TX } ;

    init () ;
}



// thread to process the messages recieved from ambTp
void RemoteCDTP::messagesWorker ( )
{
	while ( ! stopped_ )        // until megaTp is not stopped work on the queue of messages
	{
     
        tpData data = nullptr ;

        ScopedLock lock ( sync_ ) ;
        while ( getMessages (). empty () )    cv_. wait ( lock ) ;   // wait forever until there is data to consume from ambTp 
       
        // data available now go get it and process if we are interested in the message received
        data = getMessage () ;
     
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d below are the data for signal Id 0x%x", __FUNCTION__, __LINE__, data-> tpdata [ 0 ] ); 
        
    for ( unsigned int i = 1; i < data-> size ; i++ )    
     {
         LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  0x%x", __FUNCTION__, __LINE__, data-> tpdata [ i ] ); 
     }
        if ( interestedMessage ( data ) )    messageIdHandlerMap_ [ (data)->tpdata [ 0 ] ] ( data ) ;

        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d processed message with length %d signalId 0x%x", __FUNCTION__, __LINE__, data-> size, (data)->tpdata [ 0 ] ) ;
        // processed the item remove it from the queue
        removeMessage () ;
    }
}

/*****   message/ data handlers   *****/

bool RemoteCDTP::folderMetaDataReceived ( tpData data )
{
    if ( data != nullptr )
    {
    int offset = HEADER_BYTES ; // skip header bytes & start with reading the payload data
    
    int codingType = (data)->tpdata [ offset - 1 ];
    
    short folderNumber = ( ( (data)->tpdata [ offset++ ] ) << 8 | ( (data)->tpdata [ offset++ ] ) ) ;
    
    
    
    string folderName  = getName ( offset, codingType, data ) ;
    
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:   %d   <folderName : %s, folderNumber : %d>  ", __FUNCTION__, __LINE__, folderName.c_str(), folderNumber ) ;

   // memcpy ( const_cast < char * > ( folderName. data () ), &( (data)->tpdata [ offset ] ), ( data-> size  - offset ) ) ;
    
    // publish to client
    PRESEVENT_PUBLISH ( getFolderNameStatus, EVENT_BROWSECONTROL_GETFOLDERNAME_STATUS, folderNumber, folderName ) ;
    }
    else LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:   %d   data is nullptr ", __FUNCTION__, __LINE__) ;

    return true ;
}





bool RemoteCDTP::activeFolderInfoReceived ( tpData data )
{
      
    bool success = false ;
    if ( data != nullptr )
    {  
    CDActiveFolder folder ;
    unsigned int offset = ACTIVE_FOLDER_PAYLOAD_OFFSET ;

    if ( getFolderSummary ( offset, data, folder. summary ) && getFolderPath ( offset + 9 , data, folder. path ) )
    {
        // publish to client to cache or pass it mpres client
        PRESEVENT_PUBLISH ( activeFolder, EVENT_PLAYCONTROL_ACTIVEFOLDER_STATUS, folder ) ;
        success = true ;
    }
    }
    else LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:   %d   data is nullptr ", __FUNCTION__, __LINE__) ;
    return success ;
}

// first byte decides which name has been received among one of these - artistName, albumName, genreName, fileName, folderName, trackName.
bool RemoteCDTP::nameReceived ( tpData data )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:   %d ", __FUNCTION__, __LINE__) ;
    
  
    int offset = HEADER_BYTES ; // skip header bytes & start with reading the payload data
    char codingType = (data)->tpdata [ offset - 1 ] ;  // last byte in the header is the coding type

    
    string name  = getName ( offset, codingType, data ) ;
    
    if ( name.length() != 0 )
      {
        
              nowPlayingName namePair = make_pair ( namesMessageIdsMap_ [ (data)->tpdata [ 0 ] ], name ) ;
              nowPlayInfo. names_. push_back ( namePair ) ;
    
              nowPlayInfo. namesAvailable_ |= namesMessageIdsMap_ [ (data)->tpdata [ 0 ] ] ;
              
              if ( RemoteCDPlayControls::TimerExpired == true )
              {
                  PRESEVENT_PUBLISH ( cdNowPlayingInfo, EVENT_PLAYCONTROL_NOWPLAYING_STATUS, nowPlayInfo ) ;
                   LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sending NowPlaying data update after timer got expired  ", __FUNCTION__, __LINE__  ) ;
              }

         
      }
    
    else
      {
           LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Sending NowPlaying data names signalId 0x%x Empty String found ", __FUNCTION__, __LINE__ , (data)->tpdata [ 0 ]) ;
      }
            
       
    
    return true ;
}

bool RemoteCDTP::CDTableOfContentsReceived ( tpData data )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:   %d ", __FUNCTION__, __LINE__) ;
    CDTableofContents contents;
    if ( data != nullptr )
    {
    
    // sanity checks on the data - checking if the data size is sufficient enough to hold valid TOCItems contents
    if ( ( data-> size - HEADER_BYTES ) % TOC_RECORD_SIZE == 0 )
    {
        for ( unsigned int i = HEADER_BYTES; i < data-> size ; i += TOC_RECORD_SIZE )
        {
            char itemIndex = (data)->tpdata [ i ] ;    // 1st byte is for index
            short item = ( ( (data)->tpdata [ i + 1 ] << 16 ) | ( (data)->tpdata [ i + 2 ] << 8 ) | ( (data)->tpdata [ i + 3 ] ) ) ; // next 3 bytes containg the item id/ data

            contents. push_back ( make_pair ( itemIndex, item ) ) ;
        }
        // publish to client
        
        
    Folder root = make_shared < FolderData > ( 0, -1, "" ) ;

    for ( auto &content : contents )
    {
        Item item = make_shared < ItemData > ( ) ;

        string name = "Track " ;
        name += to_string ( content. first ) ;

        item-> setIndex ( content. first ) ;
        item-> setName ( name ) ;
        item-> setType ( eFile ) ;
        item-> setNumber ( make_pair ( 0, content. first ) ) ;

        root-> addItem ( item ) ;
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d inserted record <%d,%s>", __FUNCTION__, __LINE__, item-> getIndex (), item-> getName (). c_str () ) ;
    }
    
    root -> setTotalItemCount ( static_cast <unsigned short > ( contents. size () ) );
    
    PRESEVENT_PUBLISH ( browseStatus, EVENT_BROWSECONTROL_BROWSEINFO_STATUS, root, true ) ;
    
//        PRESEVENT_PUBLISH ( tocDataUpdate, EVENT_TOC_DATA_UPDATE, contents ) ;
    }
    else    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d invalid data %d sent for CDTOC", __FUNCTION__, __LINE__, data-> size ) ;
    
    }
    else LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:   %d   data is nullptr ", __FUNCTION__, __LINE__) ;

    return ( contents. size () > 0 ) ;
}

bool RemoteCDTP::MPInfoReceived ( tpData data )
{
    if ( data != nullptr )
    {
    
    if ( data-> size  > HEADER_BYTES + 5 )
    {
        int offset = HEADER_BYTES ; // skip header bytes & start with reading the payload data

        char codingType = (data)->tpdata [ offset - 1 ] ;  // last byte in the header is the coding type

        Folder contents = make_shared < FolderData > () ;

        // populate folder metadata which is streamed first in the tp message
        contents-> setNumber ( ( (data)->tpdata [ offset ] ) << 8 | ( (data)->tpdata [ ++offset ] ) ) ;
        
        short TotalItemCount = ( ( (data)->tpdata [ ++offset ] ) << 8 | ( (data)->tpdata [ ++offset ] ) ) ;
        
        
        contents-> setTotalItemCount( TotalItemCount  ) ; 
        
        short itemsCount = (data)->tpdata [ ++offset ];  // ignore itemsCount

        
        contents-> setTotalItems ( TotalItemCount ) ;

        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d < FolderNumber: %d TotalItems %d itemCount :%d > ", __FUNCTION__, __LINE__, contents-> getNumber (), contents-> getTotalItems () , itemsCount) ;
        // populate individual items data now
        if ( getFolderItemsData ( offset, codingType, data, contents, itemsCount ) )
        {
            PRESEVENT_PUBLISH ( browseStatus, EVENT_BROWSECONTROL_BROWSEINFO_STATUS, contents, true ) ;
            PRESEVENT_PUBLISH ( folderDataUpdate, EVENT_FOLDER_DATA_UPDATE, contents, true ) ;
        }
        
        if ( itemsCount == 1 )
        {
            PRESEVENT_PUBLISH ( browseTotalCount , EVENT_BROWSECONTROL_TOTAL_FOLDER_COUNT, TotalItemCount  ) ;
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:   %d   itemCount : %d  ", __FUNCTION__, __LINE__, itemsCount ) ;
            return true;
        }
        return ( contents-> getItemsList(). size () > 0 ) ;
    }
    else    
    {
        LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d invalid data %d sent for MPInfo", __FUNCTION__, __LINE__, data-> size ) ;
        PRESEVENT_PUBLISH ( browseTotalCount , EVENT_BROWSECONTROL_TOTAL_FOLDER_COUNT, 0 ) ;
        return false;
    }
    
    }
    else LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:   %d   data is nullptr ", __FUNCTION__, __LINE__) ;
   return true;
}

/*****   EXTERN or Client data update calls   *****/

// callback that is registered to ambtpclient and will copy the received packet into the messages queue 
void RemoteCDTP::onDataReceived ( tpRequest_s* data )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d dataLen %d", __FUNCTION__, __LINE__, data-> dataLen ) ; 
    
    // for ( unsigned int i = 0; i < data-> dataLen; i++ )    LOG_DEBUG ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d 0x%x", __FUNCTION__, __LINE__, data-> reqData [ i ] ) ; 

	if ( ( data-> dataLen > HEADER_BYTES ) && ( data-> dataLen <= MESSAGE_SIZE ) )
    {
        // make a local copy of the ambTp data received
        
        tpData payload = (tpData) malloc( sizeof (TPData)) ;
        if(payload) {
        	payload->tpdata = (uint8_t*) malloc ( sizeof(char)*(data-> dataLen));
            if ( payload->tpdata != NULL )
            {
        	payload->size = data->dataLen;
        	cout << "size of TPData" << sizeof(TPData) << endl;
        	memset( payload->tpdata , '\0', data-> dataLen );
        	memcpy( payload->tpdata  , data->reqData , data->dataLen);
        	//payload-> assign ( data-> reqData, data-> reqData + data-> dataLen ) ;

        	// add the copy of data to the messages queue for further processing of the same
        	ScopedLock lock ( sync_ ) ;

        	addMessage ( payload ) ;
        	cv_. notify_one () ;    // notify messagesWorker_ thread to consume this data
            }
            else
            {
                LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d malloc returns null", __FUNCTION__, __LINE__ ) ;
            }
        }
    }
    else    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d invalid dataLen from ambTp recieved %d requiredMaxSize %d", __FUNCTION__, __LINE__, data-> dataLen, MESSAGE_SIZE ) ;
}

/*****   HELPERS/ Utility   *****/
int RemoteCDTP::init ( void )
{
    // start messagesWorker to consume the queued messages if any. 
    messageWorker_ = thread ( bind ( &RemoteCDTP::messagesWorker, this ) ) ;

    // initialize the ambTp library
    int ret = initTpLib () ;
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Initialized ambTP library ret %d", __FUNCTION__, __LINE__, ret ) ; 

    // register the CanIds we are interested in along with callbacks for data receiving from ambTp
    for ( auto canId : canIds_ )
    {
        ret = registerTPMessage ( canId, &RemoteCDTP::onDataReceived, &RemoteCDTP::statusCallBack ) ;
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d registered canId 0x%x ret %d", __FUNCTION__, __LINE__, canId, ret ) ; 
    }

    initDataHandlers () ;
    return ret ;
}

// returns true if we are interested in the current message we received from ambTp available in @param data
bool RemoteCDTP::interestedMessage ( tpData data )
{
	// we are only interested in the data coming from CD and not from other sources like bluetooth, USB etc,.
	bool interested = ( ( data->tpdata != nullptr ) && ( (data->tpdata[ 1 ] == CD_UTILIZATION ) ) ) ;

	// interested only in the messages that we are supposed to handle and display currently
	if ( interested ) {
		interested = ( messageIdHandlerMap_. find ( (data)->tpdata [ 0 ] ) != messageIdHandlerMap_. end () ) ;
		LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d source %d interested %d", __FUNCTION__, __LINE__, (data)->tpdata [ 1 ], interested ) ;
	}
	return interested ;
}

bool RemoteCDTP::getFolderSummary ( unsigned int offset, tpData data, FolderSummary &summary )
{
   // sanity checks on the data - checking if the data size is sufficient enough to hold valid folderSummary contents
    if ( ( data-> size  - offset ) >= FOLDER_SUMMARY_SIZE )
    {
        for ( ; offset < data-> size ; offset += FOLDER_SUMMARY_RECORD_SIZE )
        {
            short NumberOfItems = ( ( (data)->tpdata [ offset + 1 ] << 8 ) | ( (data)->tpdata [ offset + 2 ] ) ) ;
           // skip first 5 bits it is reserved for now

            char type = (data)->tpdata [ offset ]  ;
             // discard the contentType bits

            LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <%d,%d> ", __FUNCTION__, __LINE__, type, NumberOfItems ) ;

            // now we have contentType in type variable and summaryRecord is the left out bytes which is nothing but numItems in that type so just push as is
            summary. push_back ( make_pair ( type, NumberOfItems ) ) ;
        }
    }
    else    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d invalid data <type, numItems - data part> sent for ActiveFolderInfo size %d", __FUNCTION__, __LINE__, data-> size  ) ;

    return ( summary. size () > 0 ) ;

  
}

bool RemoteCDTP::getFolderPath ( unsigned int offset, tpData data, FolderPath &path )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d just for testing <offset: %d, size: %d>", __FUNCTION__, __LINE__, offset, data->size ) ;
    // sanity checks on the data - checking if the data size is sufficient enough to hold valid folderPath contents
    if ( ( data-> size  - offset ) % FOLDER_PATH_RECORD_SIZE == 0 )
    {
        for ( unsigned int i = offset; i < data-> size ; i += FOLDER_PATH_RECORD_SIZE ) // each record is of 4 bytes, first 2 bytes for folder number, second 2 bytes for itemIndex
        {
            short folderNumber = ( ( (data)->tpdata [ i ] << 8 ) | ( (data)->tpdata [ i + 1 ] ) ) ;
            short itemIndex    = ( ( (data)->tpdata [ i + 2 ] << 8 ) | ( (data)->tpdata [ i + 3 ] ) ) ;

            path. push_back ( make_pair ( folderNumber, itemIndex ) ) ;
        }
    } 
    else    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d invalid data <folderpath - data part> sent for ActiveFolderInfo size %d", __FUNCTION__, __LINE__, data-> size  ) ;

    return ( path. size () > 0 ) ;
   
}

bool RemoteCDTP::getFolderItemsData ( int &offset, char codingType, tpData data, Folder contents, int itemsCount )
{
    for (int i = 0; i < itemsCount; i++ )
    {
        Item item = make_shared < ItemData > ( ) ;

        int itemIndex_ = ( (data)->tpdata [ ++offset ] ) << 8 | ( (data)->tpdata [ ++offset ] ) ;
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <itemindex : %d>", __FUNCTION__, __LINE__, itemIndex_ ) ;
        item-> setIndex ( itemIndex_ + 1 ) ;

        item-> setName ( getName ( ++offset, codingType, data ) ) ;
        item-> setType ( static_cast < eItemType > ( (data)->tpdata [ ++offset ] ) ) ;
       
        // get TrackNumber and set it, this is a pair of folderNumber & trackIndex in that folder, for folder types, the itemIndex would be sent as 0 by the CD player
        short folderNumber = ( ( (data)->tpdata [ ++offset ] ) << 8 | ( (data)->tpdata [ ++offset ] ) ) ;
        short trackIndex   = ( ( (data)->tpdata [ ++offset ] ) << 8 | ( (data)->tpdata [ ++offset ] ) ) ;
        item-> setNumber ( make_pair ( folderNumber, trackIndex ) ) ;
        
        contents-> addItem ( item ) ;
        LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Folder %d added item <%d,%s,%d,<%d,%d>>", __FUNCTION__, __LINE__, contents-> getNumber (), item-> getIndex (), 
                                                                                        item-> getName (). c_str (), item-> getType (), item-> getNumber (). first, item-> getNumber (). second ) ;
    }
    return true ;
}

string RemoteCDTP::getName ( int &offset, char codingType, tpData data )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:   %d ", __FUNCTION__, __LINE__) ;
    string input ;
    
    // names can come in unicode 16 - 2 byte per char or utf-8 1 byte per char so parse accordingly but we do not support unicode at present to check with HMI
    if ( codingType == 0x1 )
    {
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d coding latin", __FUNCTION__, __LINE__ ) ;
        size_t inbufLen =  offset ;
        // means utf8 read until end of string char & return the data
       for ( ; (data)->tpdata [ offset] != '\0' ;  offset++ ) input += (data)->tpdata [ offset];
       
        inbufLen = offset - inbufLen ;
       
        offset++;
       
       // Current CTR system only supports LATIN - 1 , Hence  these characters in Latin - 9  (   € Œ œ Ÿ  ž Ž š Š ) will be replaced by
       // these characters in Latin - 1 ( ¤ ¼ ½ ¾ ¸ ´ ¦ ) 
       
       convertToUtf8 ( CODING_LATIN_9  , input , inbufLen ) ; 
    
       LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:   %d : name : %s , namelength: %d , codingtype: %d, inbufLen : %d ", __FUNCTION__, __LINE__, input.c_str(), input.length(), codingType, inbufLen) ;
    }
    else
    {

        
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d coding utf16", __FUNCTION__, __LINE__ ) ;
        
        
       offset--;
       size_t inbufLen =  offset ;
       
        for( ; ! ( ( (data)->tpdata [ offset +1  ] == '\0' ) && ( (data)->tpdata [ offset + 2 ] == '\0') ) ;  offset = offset +2  )
        {
           LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d coding utf16 : 0x%0x,  0x%0x ", __FUNCTION__, __LINE__ , (data)->tpdata [ offset +1  ] , (data)->tpdata [ offset + 2 ] ) ;
            input += (data)->tpdata [ offset +1  ] ;
            input += (data)->tpdata [ offset +2  ] ;
            
        }
        
        
        
         inbufLen = offset - inbufLen ;
        
        // To advance the offset for future items 
        offset = offset + 2;
        
          
       
        
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d coding utf16 inbuf lenght: %d", __FUNCTION__, __LINE__ , inbufLen) ;
            

        convertToUtf8 ( CODING_UTF_16  , input , inbufLen ) ;    
   
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d UTF16 name %s namelen %d", __FUNCTION__, __LINE__, codingType, input. c_str (), input. length () ) ;

        
        
    }
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d codingType %d name %s namelen %d", __FUNCTION__, __LINE__, codingType, input. c_str (), input. length () ) ;

    return input ;
}


iconv_t  RemoteCDTP::getConversionId (  eCodingType mCodingType ) 

{  
    // Here the conversion is done for UTF - 16 BE to utf8 and Latin - 1 to UTF -8 
        cd  = (( mCodingType ==  CODING_UTF_16 ) ? iconv_open("UTF-8", "UTF-16BE") :  iconv_open("UTF-8","ISO_8859-15" ) ) ;
        return cd ;
}

void      RemoteCDTP::convertToUtf8              (    eCodingType codingType ,    string&   input , size_t inbufLen )
{
            cleanConversionOutBuf ();
    
            iconv_t cd = getConversionId ( codingType ) ;

            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d coding utf16 A3 : %d , inputbufLen : %d supported ISO15 ", __FUNCTION__, __LINE__ , cd , inbufLen) ;


            if ((int) cd == -1) {
            /* Initialization failure. */
            
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  Initialization failure %s ", __FUNCTION__, __LINE__, strerror (errno) ) ;
     
            }



            char* inbuf = ( char* ) input.c_str () ;
            
            // outBufLen can be twice of the current length

            size_t outbufLen = CONVERSION_OUTBUF_MAX_SIZE ;
            
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  iconv outbuflen  %d ", __FUNCTION__, __LINE__, outbufLen ) ;
            char* outbuf =   getConversionOutBuf  ();




            size_t retVal = iconv(cd, &inbuf, &inbufLen,
            &outbuf, &outbufLen);

        if  (  retVal == -1  )
        {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  iconv failure %s ", __FUNCTION__, __LINE__, strerror (errno) ) ;
        }

            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  iconv success  %s ", __FUNCTION__, __LINE__, getConversionOutBuf  () ) ;
            input = getConversionOutBuf  ();

            cleanConversionOutBuf ();

            iconv_close(cd) ;
    
}







void RemoteCDTP::initDataHandlers ()
{
    //TBD: check if we have to something for mediaInformation_St as per transport document this is also there for CD, but design wise this shall given from MediaPlayer server to MediaPlayerClient
    messageIdHandlerMap_ = 
    {
        /* getFolderNameRsp */  {   0x52,   bind ( &RemoteCDTP::folderMetaDataReceived,       this,   _1 )   },
        /* getMPInfoRsp */      {   0x3D,   bind ( &RemoteCDTP::MPInfoReceived,               this,   _1 )   }, 
        /* activeFolderSt */    {   0x3E,   bind ( &RemoteCDTP::activeFolderInfoReceived,     this,   _1 )   }, 
        /* albumNameSt */       {   0x3F,   bind ( &RemoteCDTP::nameReceived,                 this,   _1 )   }, 
        /* artistNameSt */      {   0x42,   bind ( &RemoteCDTP::nameReceived,                 this,   _1 )   }, 
        /* fileNameSt */        {   0x43,   bind ( &RemoteCDTP::nameReceived,                 this,   _1 )   }, 
        /* folderNameSt */      {   0x44,   bind ( &RemoteCDTP::nameReceived,                 this,   _1 )   }, 
        /* genreNameSt */       {   0x45,   bind ( &RemoteCDTP::nameReceived,                 this,   _1 )   }, 
        /* trackNameSt */       {   0x46,   bind ( &RemoteCDTP::nameReceived,                 this,   _1 )   }, 
        /* getCDTOCDataRsp */   {   0x64,   bind ( &RemoteCDTP::CDTableOfContentsReceived,    this,   _1 )   }
    };

    namesMessageIdsMap_ = 
    {
        {  0x3F,  eAlbumName    },
        {  0x42,  eArtistName   },
        {  0x43,  eFileName     },
        {  0x44,  eFolderName   },
        {  0x45,  eGenreName    },
        {  0x46,  eTrackName    }
    };
}

void RemoteCDTP::statusCallBack ( tpTxStatus_s* tmp )   {   }

RemoteCDTP::~RemoteCDTP ()
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%:%d", __FUNCTION__, __LINE__ ) ;
    stopped_ = true ;
    delete [] Conversionoutbuf;
}
