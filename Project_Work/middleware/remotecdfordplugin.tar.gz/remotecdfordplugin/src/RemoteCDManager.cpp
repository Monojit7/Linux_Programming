
#include <dlfcn.h>
#include <RemoteCDManager.hpp>
#include <iostream>
#include <memory>
#include <unistd.h> 

// global instance for logging all the components debug/ error traces
// RemoteCDLog     cdLog ;

/*****  Plugin API hooks called by client *****/

#if 1
// below API is callback from PluginLoader for creation of plugin
IRemoteCDPlugin* CreatePlugin ()
{
    return  RemoteCDManager::getInstance ( ) ;
}

// below API gets called for deletion of plugin
void DestroyPlugin ( IRemoteCDPlugin* remotecdInstance )
{
    
    delete remotecdInstance ;
}
/***** End of Plugin API implementation *****/
#endif

// class members
RemoteCDManager* RemoteCDManager::instance_ = nullptr ;

RemoteCDManager::RemoteCDManager () : IRemoteCDPlugin ( "RemoteCD" ), player_ ( "local", "AutomotiveMessageBrokerProvider.ford_MediaPlayback" ),
keyInput_ ( "local", "AutomotiveMessageBrokerProvider.ford_keyInput" ), notifalert_ ( "local", "AutomotiveMessageBrokerProvider.ford_NotifAlert"  ),
bodyControlData_( "local", "AutomotiveMessageBrokerProvider.ford_BodyCtrlData" ), subscribed_ ( false ), ejectShowPopup_ ( true ), Warning_Popup(false)
{
    // setup the logger
    // cdLog. init () ;

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d using media context logging instead of RCD will change when remotecdcomponent is made as plugin", __FUNCTION__, __LINE__ ) ;
}

// client calls us to init - done by pluginLoader
bool RemoteCDManager::init ()
{
    // init members
    
    cdType_      =  eUnknownCD ;
    cdStatus_    =  eInvalidStatus ;
    cdError_     =  { eInvalidError, eInvalidHWError } ;
    
#if 1
    
    this-> initEXTEOL ();

#else
    // subscribe to player proxy availability
    
    playControl_     = make_shared < RemoteCDPlayControls > ( player_ ) ;
    browser_         = make_shared < RemoteCDBrowse > () ;
    tp_              = make_shared < RemoteCDTP > () ;

    SUBSCRIBE (  player_, getProxyStatusEvent (), &RemoteCDManager::playerAvailable, _1 ) ;
    SUBSCRIBE (  keyInput_, getProxyStatusEvent (), &RemoteCDManager::keyInputAvailable, _1 ) ;
    
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d ", __FUNCTION__, __LINE__ ) ;
#endif

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__ ) ;
    return true ;
}


void    RemoteCDManager::initEXTEOL ()
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d ", __FUNCTION__, __LINE__ ) ;
 
        // create instances of other modules of the plugin which Manager would interact with
    RemoteCDConfig_  = make_shared < CRemoteCDConfig >  ();
    
    if  ( RemoteCDConfig_ -> CheckIfExtCDPresent ()  )
          {
             
              playControl_     = make_shared < RemoteCDPlayControls > ( player_ ) ;
              browser_         = make_shared < RemoteCDBrowse > () ;
              tp_              = make_shared < RemoteCDTP > () ;

              SUBSCRIBE (  player_, getProxyStatusEvent (), &RemoteCDManager::playerAvailable, _1 ) ;
              SUBSCRIBE (  keyInput_, getProxyStatusEvent (), &RemoteCDManager::keyInputAvailable, _1 ) ; 
              SUBSCRIBE (  bodyControlData_, getProxyStatusEvent (), &RemoteCDManager::bodyControlDataAvailable, _1 ) ;
              SUBSCRIBE (  notifalert_, getProxyStatusEvent (), &RemoteCDManager::notifalertAvailable, _1 ) ;
              LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d External CD  Present Hence  initialized", __FUNCTION__, __LINE__ ) ;
            //if ( RemoteCDConfig_->getFordEOLData () == EXT_CD_PRESENT_WARNING_POPUP )
            //{
                
            //}

            
          }
    else
         {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d External CD not Present Hence not initialized", __FUNCTION__, __LINE__ ) ;
         }
    
    if  ( RemoteCDConfig_ -> CheckIfWarningPopupRequired ( ) )
        {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Warning popUp and Eject CD required", __FUNCTION__, __LINE__ ) ;
        }
    else
        {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Warning popUp and Eject CD Not required", __FUNCTION__, __LINE__ ) ;
        }
        
}

void RemoteCDManager::bodyControlDataAvailable ( const CommonAPI::AvailabilityStatus& status )
{
	bool available = ( CommonAPI::AvailabilityStatus::AVAILABLE == status ) ;
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d bodyControlData proxy Available  Proxy %s ", __FUNCTION__, __LINE__, ( available )? "" : "not" ) ;
    // subscribe/ unsubscribe to platform signals through which we get the player data or notifications
    if (available)
    {
    	SUBSCRIBE (  bodyControlData_ , getVeh_V_ActlEngAttribute (). getChangedEvent (), &RemoteCDManager::ActlEngAttributeEvent, _1 );
    }
}

bool RemoteCDManager::deInit ()
{
    // unsubscribe signals to stop receiving notifications from player via platform 
    if ( subscribed_ )    subscribeSignals ( false ) ;

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__ ) ;

    return true ;
}

/*****   EXTERN calls from client or signals/ notifications from amb/ platform   *****/

/*  client calls - client is mediapres component for ford */

// play controls related calls
void RemoteCDManager::setAction ( eCDPlayActions action )
{
    if ( validCD () )    playControl_-> setAction ( action ) ;

    else    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d client calls for playAction %d but we do not have valid CD notified by player", __FUNCTION__, __LINE__, action ) ;
}

void RemoteCDManager::setContext ( CDPlayContext context )
{
    if ( validCD () )    playControl_-> setContext ( context ) ;

    else    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d client calls for setContext %d for Play but we do not have valid CD notified by player", __FUNCTION__, __LINE__, context ) ;
}

void RemoteCDManager::setPlayItem ( CDPlayItem item ) 
{
    if ( validCD () )    playControl_-> setPlayItem ( item ) ; 

    else    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d client calls for playItem < %d, %d, <%d %d> > but we do not have valid CD notified by player", __FUNCTION__, __LINE__,
                                                                                   item. direction_, item. type_, item. number_. first, item. number_. second ) ;
}

// browse related calls from client

void RemoteCDManager::getFolderName ( short folderNumber, int nameLength, FolderRequestedData::eCutNameType cutName )
{
    if ( validCD () )    browser_-> getFolderName ( folderNumber, nameLength, cutName ) ;

    else    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d client calls for folderName browse %d but we do not have valid CD notified by player", __FUNCTION__, __LINE__, folderNumber ) ;
}

void RemoteCDManager::getBrowseInfo ( FolderRequest request )
{
    if ( validCD () )    browser_-> getBrowseInfo ( request ) ;

    else    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d client calls for folder %d details for browse %d but we do not have valid CD notified by player", __FUNCTION__, __LINE__, request-> getNumber () ) ;
}

eEOLResult RemoteCDManager::getFordEolData ()  
{ 
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d start  ", __FUNCTION__, __LINE__) ;
    if ( RemoteCDConfig_ ) 
    {
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  < getFordEolData true > ", __FUNCTION__, __LINE__) ;
        
         return  RemoteCDConfig_ -> getFordEOLData ()  ; 
    }
    else
    {
         LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  < getFordEolData false > ", __FUNCTION__, __LINE__) ;
         return EXT_CD_PRESENT_NO_CONFIGURED;
    }

  // LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d end  ", __FUNCTION__, __LINE__) ;
} 

// ignition of disc - load/ Eject
void RemoteCDManager::load ( bool Load )
{
    // not sure if we support this in our feature this is when HMI would have a LOAD/ EJECT options
}

/* amb/ plf signals */

void RemoteCDManager::playerAvailable ( const CommonAPI::AvailabilityStatus& status )
{
    bool available = ( CommonAPI::AvailabilityStatus::AVAILABLE == status ) ;
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d player Proxy %s available", __FUNCTION__, __LINE__, ( available )? "" : "not" ) ;

    // subscribe/ unsubscribe to platform signals through which we get the player data or notifications
    if ( available != subscribed_ )    subscribeSignals ( available ) ;

    PRESEVENT_PUBLISH ( playerAvailability, EVENT_PLAYER_PROXY_AVAILABLE, ( CommonAPI::AvailabilityStatus::AVAILABLE == status ) ) ;
}

void RemoteCDManager::keyInputAvailable ( const CommonAPI::AvailabilityStatus& status )
{
    bool available = ( CommonAPI::AvailabilityStatus::AVAILABLE == status ) ;
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d keyInput proxy Available  Proxy %s ", __FUNCTION__, __LINE__, ( available )? "" : "not" ) ;
    
    SUBSCRIBE (  keyInput_ , getEFP2_Button_PressAttribute (). getChangedEvent (), &RemoteCDManager::eep2ButtonPresEvent, _1 );
    

    // subscribe/ unsubscribe to platform signals through which we get the player data or notifications
    
}


void RemoteCDManager::notifalertAvailable  ( const CommonAPI::AvailabilityStatus& status )
{
    bool available = ( CommonAPI::AvailabilityStatus::AVAILABLE == status ) ;
    if (available) {
        notifalert_-> getCDWarnChime_Rq_enumAttribute ().setValueAsync ( notifalert_types::CDWarnChime_Rq_enum::Literal::En_Chime_Off, bind ( &RemoteCDManager::plfCallback7, this, _1, _2 ) ) ;
        notifalert_-> getCDWarnChime_St_enumAttribute ().setValueAsync ( notifalert_types::CDWarnChime_St_enum::Literal::En_Chime_Off , bind ( &RemoteCDManager::plfCallback8, this, _1, _2 ) ) ;
    }
     LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d notifalertAvailable Proxy %s available", __FUNCTION__, __LINE__, ( available )? "" : "not" ) ;
}
    
// signal5 from amb carries information about shuffle, repeat, operationMode, MagazineSlots & discCoding
void RemoteCDManager::ACUSignals5 ( mediaplayback_types::ACU_Send_Signals_5_struct signal )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d ", __FUNCTION__, __LINE__ ) ;
    // here as a Manager we are only interested in MagazineSlots & discCoding which tells abou the CDStatus & CDType respectively
    processCDType ( signal. getACU_DiscCoding_St_enum () ) ;
}

// CD signal from amb carries information about FunctionStatus, HardwareError, CDError
void RemoteCDManager::CDSignals ( mediaplayback_types::CD_Send_Signals_struct signal )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d ", __FUNCTION__, __LINE__ ) ;
    
     // process CDStatus in case of no error
    //  if ( ( cdError_. first == eNoError ) && ( cdError_. second == eNoHWError ) ) 
    processCDStatus ( signal. getCD_FunctionStatus_St_enum () ) ;
    
    if ( ! ( ( signal. getCD_FunctionStatus_St_enum () ==  mediaplayback_types::CD_FunctionStatus_St_enum::Literal::En_Invalid ) && 
        ( signal. getCDError_St_enum () ==  mediaplayback_types::CDError_St_enum::Literal::En_NoDiscs ) ) )
    {
        processCDError  ( signal. getCDError_St_enum (), signal. getCD_HardwareError_St_enum () ) ;
    }
    else
    {
        
         LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Not sending <cd status : %d , cd error : %d >", __FUNCTION__, __LINE__ ,  signal. getCD_FunctionStatus_St_enum () , signal. getCDError_St_enum ()  ) ;
    }
    
    
}


void RemoteCDManager::eep2ButtonPresEvent ( key_input_types::EFP2_Button_Press_struct mEFP2Button_ )
{
   LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <buttonId A: %d, codingButtonId : %d>", __FUNCTION__, __LINE__ , mEFP2Button_.getBtnID_A_EFP2 () , mEFP2Button_.getCoding_BtnID_A_EFP2_enum () ) ; 
   
   
   if ( ejectShowPopup_  )
   {
       LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d processing Eject request ", __FUNCTION__, __LINE__ ) ;
      processCDEject ( mEFP2Button_.getBtnID_A_EFP2 () );
   }
   
   else
   {
       LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d processing CD NoDisc error", __FUNCTION__, __LINE__ ) ;
       cdError_ = make_pair ( static_cast < eCDError > ( eNoDisc ), static_cast < eHardwareError > ( eNoHWError ) ) ;
        PRESEVENT_PUBLISH ( cdError, EVENT_CD_ERROR, cdError_ )
   }
   
}

void RemoteCDManager::ActlEngAttributeEvent ( bodycontroldata_types::Veh_V_ActlEng_struct Veh_V_ActlEng )
{
   LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <Veh_V_ActlEng : %d, Status : %d>", __FUNCTION__, __LINE__ , Veh_V_ActlEng.getVeh_V_ActlEng(), Veh_V_ActlEng.getStatus() ) ;

   mVeh_V_ActlEng = Veh_V_ActlEng;

}

void RemoteCDManager::processCDEject ( uint8_t Button_A )
{
    
    if ( Button_A == 0x34 )
    {
     LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Sending CD Eject to Client : %d", __FUNCTION__, __LINE__, Button_A ) ;
    CommonAPI::CallStatus callStatus ;

    mediaplayback_types::NAV_LoadEjectMode_Rq_enum playerEject  = static_cast < mediaplayback_types::NAV_LoadEjectMode_Rq_enum::Literal > (mediaplayback_types::NAV_LoadEjectMode_Rq_enum::En_Eject);
    player_->NAV_LoadEjectMode_Rq_method ( playerEject, callStatus );
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  < CHIME WARNING SENT >", __FUNCTION__, __LINE__ ) ;
    processCDChimeRequest ();
    }
    else
    {
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Not Sending Eject request since Button value is : %d", __FUNCTION__, __LINE__, Button_A ) ;
    }
    
}

// process chime request

void RemoteCDManager::processCDChimeRequest ()
{
	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d processCDChimeRequest chime request to platform ", __FUNCTION__, __LINE__) ;
	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "Warning_Popup %d  notifalert Availability () %d   RemoteCDConfig_CheckIfWarningPopupRequired - %d bodyControlData Availability %d ",Warning_Popup,notifalert_ -> isAvailable (),RemoteCDConfig_ -> CheckIfWarningPopupRequired ( ),bodyControlData_ -> isAvailable());
    if ( ( ! Warning_Popup ) && ( notifalert_ -> isAvailable ()  )  && ( RemoteCDConfig_ -> CheckIfWarningPopupRequired ( ) )
         && ( bodyControlData_ -> isAvailable() ) && ( mVeh_V_ActlEng.getVeh_V_ActlEng() > 0 ) )
      {
          LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sending chime request to platform Speed %d ", __FUNCTION__, __LINE__,mVeh_V_ActlEng.getVeh_V_ActlEng() ) ;
          Warning_Popup = true ;

          PRESEVENT_PUBLISH ( ejectChimesWarning, EVENT_EJECT_CHIMES_WARNING, Warning_Popup ) ;
          notifalert_-> getCDWarnChime_Rq_enumAttribute ().setValueAsync ( notifalert_types::CDWarnChime_Rq_enum::Literal::En_Chime_On, bind ( &RemoteCDManager::plfCallback7, this, _1, _2 ) ) ;
          notifalert_-> getCDWarnChime_St_enumAttribute ().setValueAsync ( notifalert_types::CDWarnChime_St_enum::Literal::En_Chime_On , bind ( &RemoteCDManager::plfCallback8, this, _1, _2 ) ) ;
      }
      else
      {
          LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Not sending chime request to platform ", __FUNCTION__, __LINE__ ) ;
      }
}

// platform callback for chime request

void    RemoteCDManager::plfCallback7 ( const CommonAPI::CallStatus& status, notifalert_types::CDWarnChime_Rq_enum  mChimeType )
{
	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful mChimeType %d", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", mChimeType ) ;
}

void    RemoteCDManager::plfCallback8 ( const CommonAPI::CallStatus& status, notifalert_types::CDWarnChime_St_enum  mChimeType )
{
	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful mChimeType %d", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", mChimeType ) ;
}

// internal calls from other modules in our plugin to interact with player

void RemoteCDManager::requestTOC () 
{
    if ( player_-> isAvailable () )
    {
        short unsigned int num = 0 ;
        unsigned char byte = 0 ;
        unsigned int track = 0 ;
        // player is available so nullfiy other attributes & their master common to this signal and request for TOC along with its master set properly
        CommonAPI::CallStatus callStatus ;

        // nullify other unrelated attributes of this CAN signal
        player_-> getDsp_FolderNumber_RqAttribute ().   setValueAsync ( num, bind ( &RemoteCDManager::plfCallback2, this, _1, _2 ) ) ;
        player_-> getDsp_ItemNameLength_RqAttribute (). setValueAsync ( byte, bind ( &RemoteCDManager::plfCallback1, this, _1, _2 ) ) ;
        player_-> getDsp_CutItem_Rq_enumAttribute ().   setValueAsync ( mediaplayback_types::Dsp_CutItem_Rq_enum::Literal::En_Beginning, bind ( &RemoteCDManager::plfCallback4, this, _1, _2 ) ) ;
        player_-> getDsp_SourceSetTrack_RqAttribute (). setValueAsync ( track, bind ( &RemoteCDManager::plfCallback3, this, _1, _2 ) ) ;
       

        // their master signal with inactive
        mediaplayback_types::Dsp_AudioSourceSel_Rq_enum source = mediaplayback_types::Dsp_AudioSourceSel_Rq_enum::Literal::En_Inactive ;
        player_-> Dsp_AudioSourceSel_Rq_method ( source, callStatus ) ;
        
        // interested one for TOC below is the master signal
        mediaplayback_types::Dsp_GetCDTOCDData_Rq_enum toc = mediaplayback_types::Dsp_GetCDTOCDData_Rq_enum::Literal::En_TOC ;
        player_-> Dsp_GetCDTOCDData_Rq_method ( toc, callStatus ) ;
        
        // This is done to solve  ioc issue , ioc does not send the data in the CAN bus 
        usleep ( 1000 * 1000 );
        
        player_-> Dsp_GetCDTOCDData_Rq_method ( mediaplayback_types::Dsp_GetCDTOCDData_Rq_enum::Literal::En_Inactive, callStatus ) ;
        LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d called player for TOC details with other master signal sent as inactive", __FUNCTION__, __LINE__ ) ;
    }
}

// request folder information to the player
void RemoteCDManager::requestFolderName ( short folderNumber, short nameLength, FolderRequestedData::eCutNameType cutname )
{
    if (  player_-> isAvailable () )
    {
        int cutName = static_cast < int > ( cutname ) ;
        // player is available so nullfiy other attributes & their master common to this signal and request for getFolderName along with its master set properly
        CommonAPI::CallStatus callStatus ;
        
        
        
        // nullify other unrelated attributes of this CAN signal
         player_-> getDsp_SourceSetTrack_RqAttribute (). setValueAsync ( 0, bind ( &RemoteCDManager::plfCallback3, this, _1, _2 ) ) ;
        // their master signal with inactive
         mediaplayback_types::Dsp_GetCDTOCDData_Rq_enum toc = mediaplayback_types::Dsp_GetCDTOCDData_Rq_enum::Literal::En_Inactive ;
         player_-> Dsp_GetCDTOCDData_Rq_method ( toc, callStatus ) ;
        
        // now set the interested ones for getFolderName
         player_-> getDsp_FolderNumber_RqAttribute ().   setValueAsync ( folderNumber, bind ( &RemoteCDManager::plfCallback2, this, _1, _2 ) ) ;
         player_-> getDsp_ItemNameLength_RqAttribute (). setValueAsync ( nameLength, bind ( &RemoteCDManager::plfCallback1, this, _1, _2 ) ) ;
         player_-> getDsp_CutItem_Rq_enumAttribute ().   setValueAsync ( static_cast < mediaplayback_types::Dsp_CutItem_Rq_enum::Literal > ( cutName ), bind ( &RemoteCDManager::plfCallback4, this, _1, _2 ) ) ;
        // below is the master signal
         mediaplayback_types::Dsp_AudioSourceSel_Rq_enum source = mediaplayback_types::Dsp_AudioSourceSel_Rq_enum::Literal::En_CD ;
         player_-> Dsp_AudioSourceSel_Rq_method ( source, callStatus ) ;

        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d data requested for folder name with %d %d %d", __FUNCTION__, __LINE__, folderNumber, nameLength, cutname ) ;
    }
}


void RemoteCDManager::getFolderItemCount ( short FolderNumber )
{
  LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <FolderNumber: %d>", __FUNCTION__, __LINE__, FolderNumber ) ;  
  browser_->getFolderCount ( FolderNumber );
}

// we always currentFolder to request and not parent as we have our cache and parent would be present always in cache - for maxCacheEntries have to take care of it later
void RemoteCDManager::requestFolder ( short folderNumber, int startIndex, int numItems )
{
    if (  player_-> isAvailable () )
    {
         // player is available so nullify other attributes & their master common to this signal and request for getFolderName along with its master set properly
         CommonAPI::CallStatus callStatus ;
        
#if 0
                  player_-> getDsp_NbrOfItems2_RqAttribute ().        setValueAsync ( numItems, bind ( &RemoteCDManager::plfCallback1, this, _1, _2 ) ) ;
         player_-> getDsp_FolderNumber2_RqAttribute ().      setValueAsync ( 0xFFFF, bind ( &RemoteCDManager::plfCallback2, this, _1, _2 ) ) ;
         player_-> getDsp_StartItemIndexRqAttribute ().      setValueAsync ( 0xFFFF, bind ( &RemoteCDManager::plfCallback2, this, _1, _2 ) ) ;
         player_-> getDsp_ItemNameLength2_RqAttribute ().    setValueAsync ( 20, bind ( &RemoteCDManager::plfCallback1, this, _1, _2 ) ) ;
         player_-> getDsp_CutItem2_Rq_enumAttribute ().      setValueAsync ( mediaplayback_types::Dsp_CutItem2_Rq_enum::En_Inactive, bind ( &RemoteCDManager::plfCallback5, this, _1, _2 ) ) ;
         player_-> getDsp_FolderContent_Rq_enumAttribute (). setValueAsync ( mediaplayback_types::Dsp_FolderContent_Rq_enum::En_RequestContentFromParameterFolde, bind ( &RemoteCDManager::plfCallback6, this, _1, _2 ) ) ;

         // below is the master signal
         player_-> Dsp_AudioSourceSel2_Rq_method ( mediaplayback_types::Dsp_AudioSourceSel2_Rq_enum::En_Inactive, callStatus ) ;
         
         sleep ( 0.02 );
#endif

         if (   static_cast < int > ( cdType_ ) != mediaplayback_types::ACU_DiscCoding_St_enum::Literal::En_Cdda__NoCDTextAvailable )
         {
         
         // now set the interested ones for getMPInfo
         player_-> getDsp_NbrOfItems2_RqAttribute ().        setValueAsync ( numItems, bind ( &RemoteCDManager::plfCallback1, this, _1, _2 ) ) ;
         player_-> getDsp_FolderNumber2_RqAttribute ().      setValueAsync ( folderNumber, bind ( &RemoteCDManager::plfCallback2, this, _1, _2 ) ) ;
         player_-> getDsp_StartItemIndexRqAttribute ().      setValueAsync ( startIndex  , bind ( &RemoteCDManager::plfCallback2, this, _1, _2 ) ) ;
         player_-> getDsp_ItemNameLength2_RqAttribute ().    setValueAsync ( 20, bind ( &RemoteCDManager::plfCallback1, this, _1, _2 ) ) ;
         player_-> getDsp_CutItem2_Rq_enumAttribute ().      setValueAsync ( mediaplayback_types::Dsp_CutItem2_Rq_enum::En_Beginning, bind ( &RemoteCDManager::plfCallback5, this, _1, _2 ) ) ;
         player_-> getDsp_FolderContent_Rq_enumAttribute (). setValueAsync ( mediaplayback_types::Dsp_FolderContent_Rq_enum::En_RequestContentFromParameterFolde, bind ( &RemoteCDManager::plfCallback6, this, _1, _2 ) ) ;

         // below is the master signal
         player_-> Dsp_AudioSourceSel2_Rq_method ( mediaplayback_types::Dsp_AudioSourceSel2_Rq_enum::En_CD, callStatus ) ;

         LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d data requested for folder with %d %d %d %d callStatus %d", __FUNCTION__, __LINE__, folderNumber, startIndex, numItems, 20, callStatus ) ;
         }
         
         else
         {
              requestTOC ();
              LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Calling requestTOC ", __FUNCTION__, __LINE__) ;
         }
    }
}

/*****   utilities/ helpers   *****/

// subscribing plf signals
void RemoteCDManager::subscribeSignals ( bool subscribe )
{
    static uint32_t cdSignals, signals5 ;
    if ( subscribe )
    {
        cdSignals = SUBSCRIBE (  player_, getCD_Send_SignalsAttribute (). getChangedEvent (), &RemoteCDManager::CDSignals, _1 ) ;
        signals5  = SUBSCRIBE (  player_, getACU_Send_Signals_5Attribute (). getChangedEvent (), &RemoteCDManager::ACUSignals5, _1 ) ;
        subscribed_ = true ;
    }
    else
    {
        UNSUBSCRIBE (  player_, getCD_Send_SignalsAttribute (). getChangedEvent (), cdSignals ) ;
        UNSUBSCRIBE (  player_, getACU_Send_Signals_5Attribute (). getChangedEvent (), signals5 ) ;
        subscribed_ = false ;
    }
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d platform signals/ notifications %ssubscribed", __FUNCTION__, __LINE__, ( subscribe )? "" : "un" ) ;
}

// returns whether we have a valid CD notified by player or not, the checks are based on 3 rules explained below
bool RemoteCDManager::validCD ()
{
    // first check for CD type notified by plf, default value for cdType_ is eUnknownCD
    bool valid = ( cdType_ != eUnknownCD ) ;

    // CD Error check it is a pair of CDError & HardwareError
    valid &= ( ( cdError_. first == eNoError ) && ( cdError_. second == eNoHWError ) ) ;

    // check whether CD contents are read and loaded else we will not be able to perform any play or browse operation with it
    valid &= ( cdStatus_ == eLoaded ) ;

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d we have%sa valid CD notified from player params checked <%d, %d, %d, %d>", __FUNCTION__, __LINE__,
                                                                        ( valid )? " ": " do not ", cdType_, cdError_. first, cdError_. second, cdStatus_ ) ;
    return valid ; 
}

void RemoteCDManager::processCDType ( int type )
{
     //if ( cdType_ != type )
     //{
        cdType_ = static_cast < eCDType > ( type ) ;

        // publish cdType to the clients
        PRESEVENT_PUBLISH ( cdType, EVENT_CD_TYPE, cdType_ )
        
        if (  ( static_cast < int > ( cdType_ ) == mediaplayback_types::ACU_DiscCoding_St_enum::Literal::En_Cdda__NoCDTextAvailable ) )
        {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  < requestTOC En_Cdda__NoCDTextAvailable >", __FUNCTION__, __LINE__ ) ;
          //  requestTOC () ;
        }
        
        else if ( ( static_cast < int > ( cdType_ ) ==  mediaplayback_types::ACU_DiscCoding_St_enum::Literal::En_Mp3 ) 
        || ( ( static_cast < int > ( cdType_ ) ==  mediaplayback_types::ACU_DiscCoding_St_enum::Literal::En_Cdda_CDTextAvailable ) ) )
        {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  < requestFolder  En_Mp3 or  En_Cdda_CDTextAvailable >", __FUNCTION__, __LINE__ ) ;
            

          //  requestFolder ( ROOT_FOLDER_NUMBER, 0, MAX_ITEM_COUNT_PER_REQUEST );
        }
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sent CDType %d received from player to the client", __FUNCTION__, __LINE__, cdType_ ) ;
        
        // request TOC for CDDA Disc
        // Removed ( static_cast < int > ( cdType_ ) == mediaplayback_types::ACU_DiscCoding_St_enum::Literal::En_Cdda_CDTextAvailable ) || as per SPSS

        
   
    //}
    //else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d CDType %d received from player is same as the one we have currently ", __FUNCTION__, __LINE__, cdType_ ) ;
}

void RemoteCDManager::processCDError ( int error, int HWError )
{
  //  if ( ( cdError_. first != error ) || ( cdError_. second != HWError ) )
   // {
        cdError_ = make_pair ( static_cast < eCDError > ( error ), static_cast < eHardwareError > ( HWError ) ) ;
        PRESEVENT_PUBLISH ( cdError, EVENT_CD_ERROR, cdError_ )

        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sent CDError <%d,%d> received from player to the client", __FUNCTION__, __LINE__, cdError_. first, cdError_. second ) ;
    //}
  //  else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d CDError <%d,%d> received from player is same as the one we have currently ", __FUNCTION__, __LINE__, error, HWError ) ;
}

void RemoteCDManager::processCDStatus ( int status )
{
  //  if ( cdStatus_ != status )
  //  {
        cdStatus_ = static_cast < eCDStatus > ( status ) ;
     
if ( cdStatus_ ==  eReading )
    
 {
        

 }

if ( (!Warning_Popup) && (cdStatus_ ==  eLoading || cdStatus_ ==  eReading) && ( RemoteCDConfig_ -> CheckIfWarningPopupRequired ( ) )) {
	 LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d  < CHIME WARNING SENT > Warning_Popup %d", __FUNCTION__, __LINE__,Warning_Popup ) ;
	 processCDChimeRequest ();
}


switch ( cdStatus_ )
    
{
    case eReading:
    case eLoading :
    case eLoaded:
    case eInsert:
        {

            ejectShowPopup_ = true;
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d < ejectShowPopup_ : %d > ", __FUNCTION__, __LINE__,  ejectShowPopup_) ;
            break;
        }
    case eRemoveDisc:
        {
        ejectShowPopup_ = false;
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d < ejectShowPopup_ : %d > ", __FUNCTION__, __LINE__,  ejectShowPopup_) ;
        break;
        }

    break;
}
        PRESEVENT_PUBLISH ( cdStatus, EVENT_CD_STATUS, cdStatus_ )
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sent CDStatus %d received from player to the client Warning_Popup %d", __FUNCTION__, __LINE__, cdStatus_ ,Warning_Popup) ;
 //   }
   // else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d CDStatus %d received from player is same as the one we have currently ", __FUNCTION__, __LINE__, status ) ;
}

void RemoteCDManager::plfCallback1 ( const CommonAPI::CallStatus& status, uint8_t plfValue )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful plfValue %d", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", plfValue ) ;
}

void RemoteCDManager::plfCallback2 ( const CommonAPI::CallStatus& status, uint16_t plfValue )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful plfValue %d", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", plfValue ) ;
}

void RemoteCDManager::plfCallback3 ( const CommonAPI::CallStatus& status, uint32_t plfValue )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful plfValue %u", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", plfValue ) ;
}

void RemoteCDManager::plfCallback4 ( const CommonAPI::CallStatus& status, mediaplayback_types::Dsp_CutItem_Rq_enum plfValue )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful cutItem2 plfValue %d", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", plfValue ) ;
}

void RemoteCDManager::plfCallback5 ( const CommonAPI::CallStatus& status, mediaplayback_types::Dsp_CutItem2_Rq_enum plfValue )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful cutItem2 plfValue %d", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", plfValue ) ;
}

void RemoteCDManager::plfCallback6 ( const CommonAPI::CallStatus& status, mediaplayback_types::Dsp_FolderContent_Rq_enum whichFolder )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful whichFolder %d", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", whichFolder ) ;
}

// destructor
RemoteCDManager::~RemoteCDManager ()
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__ ) ;
    // check if we need to have a state machine variable to confirm if already deInited then should not do the below
    deInit () ;
}

