#include "RemoteCDPlayControls.hpp"

bool RemoteCDPlayControls::TimerExpired = false  ;

extern CDNowPlaying   nowPlayInfo ;

// constructor
RemoteCDPlayControls::RemoteCDPlayControls ( CommonAPIClientAbstraction < mediaplaybackProxy >   &player )  : timer_ ( *this ), timerId_ ( 0 ), player_ ( player ), subscribed_ ( false )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__ ) ;
    init () ;
    
    PRESEVENT_SUBSCRIBE ( playerAvailability, EVENT_PLAYER_PROXY_AVAILABLE, &RemoteCDPlayControls::playerAvailable, _1 ) ;
}

/*****   EXTERN calls from client or signals/ notifications from amb/ platform   *****/

void RemoteCDPlayControls::playerAvailable ( bool available )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__ ) ;

    // playerproxy available/ unavailable now go subscribe/ unsubscribe for the signals we need from plf for play controls functionality
    if ( available != subscribed_ )    subscribeSignals ( available ) ;
}

// client ( i.e., mpres ) calls to control the play context, actions etc,.

void RemoteCDPlayControls::setAction ( eCDPlayActions action )
{
    //if ( playAction_ != action )
  //  {
        if ( ( action == eForwardSpeed1 ) || ( action == eReverseSpeed1 ) )    timerId_ = timer_. setTimer ( CTimerInterface::TIMER_ONESHOT, T_FAST ) ;
        
        // type conversion from plugin known type enum to player known type enum via int type
        int value = static_cast < int > ( action ) ;
        mediaplayback_types::NAV_SetOperationMode_Rq_enum playerAction = static_cast < mediaplayback_types::NAV_SetOperationMode_Rq_enum::Literal > ( value ) ;

        player_-> getNAV_SetOperationMode_Rq_enumAttribute (). setValueAsync ( playerAction, bind ( &RemoteCDPlayControls::plfCallback2, this, _1, _2 ) ) ;
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sent playerAction %d to the player", __FUNCTION__, __LINE__, playerAction ) ;
   // }
   // else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d client sent same action %d which is same as current one", __FUNCTION__, __LINE__, action ) ;
}

// client calls this to set the play context - shuffle, repeat, scan settings
void RemoteCDPlayControls::setContext ( CDPlayContext request )
{
  LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d client request type : %d, request action : %d", __FUNCTION__, __LINE__, request.first , request.second ) ;
  setContextToPlayer ( request ) ;

}

// client calls this to playfolder, settrack, skiptrack 
void RemoteCDPlayControls::setPlayItem ( CDPlayItem item )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d item. direction %d from client: item. type_ : %d item. number . second  : %d , item . number .first : %d", __FUNCTION__, __LINE__, item. direction_ , item. type_ , item. number_. second, item. number_. first ) ;
    if ( item. type_ == ePlayFolder )    setPlayFolderToPlayer ( item. number_. second ) ;
    
    else if ( item. type_ == eTrack )    setTrackToPlayer ( item. direction_, item. number_ ) ;
    
    else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d invalid params for playItem from client currently we only support ePlayFolder & eTrack", __FUNCTION__, __LINE__ ) ;
}

// amb/ plf signals

// signal5 from amb carries information about shuffle, repeat, operationMode
void RemoteCDPlayControls::ACUSignals5 ( mediaplayback_types::ACU_Send_Signals_5_struct signal )
{
    int shuffleValue = static_cast < int > ( signal. getACU_CDShuffle_St_enum () ) ;
    int repeatValue  = static_cast < int > ( signal. getACU_CDRepeat_St_enum () ) ;
    int cdType       = static_cast < int >  ( signal. getACU_DiscCoding_St_enum () ) ;
    cdType_         = static_cast < eCDType > ( cdType );
    
    processPlayAction ( static_cast < int > ( signal. getACU_OperationMode_St_enum () ) ) ;
    
    processPlayContext ( make_pair ( eShuffle, static_cast < eCDActionContextValue > ( shuffleValue ) ) ) ;
    processPlayContext ( make_pair ( eRepeat,  static_cast < eCDActionContextValue > ( repeatValue ) ) ) ;
}

// signal6 from amb carries information about playtimes - trackplaytime & totaltrackTime & number of tracks
void RemoteCDPlayControls::ACUSignals6 ( mediaplayback_types::ACU_Send_Signals_6_struct signal )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d values received from platform TrackTime %d TotalTime %d and numberofTracks: %d", __FUNCTION__, __LINE__, signal. getACU_TrackPlaytime_St (), signal. getACU_TotalPlayTime_St (), signal. getACU_NumberofTracks_St () ) ;
    processPlayTime ( ( signal. getACU_TrackPlaytime_St () + PLAYTIME_OFFSET ) , ( signal. getACU_TotalPlayTime_St () + PLAYTIME_OFFSET ) ) ;
    processNumberOfTracks ( signal. getACU_NumberofTracks_St () ) ;

}

// active track number somes in signal6 from amb
void RemoteCDPlayControls::ACUSignals9 ( mediaplayback_types::ACU_SendSignals_9_struct signal )
{
    uint32_t trackNum = signal. getACU_ActiveTrackNum1_St () ;

    short folderNumber = static_cast < short > ( ( trackNum >> 16 ) & 0xFF ) ;
    short trackNumber  = static_cast < short > ( trackNum & 0xFF ) ;

    if ( ( activeTrack_. first != folderNumber ) || ( activeTrack_. second != trackNumber ) )
   {
        activeTrack_ = make_pair ( folderNumber, trackNumber ) ;
        
        uint64_t mTrackIndex = static_cast < uint64_t > ( activeTrack_.second );

        // send active track received from the player to the client 
        PRESEVENT_PUBLISH ( activeTrack, EVENT_PLAYCONTROL_ACTIVETRACK_STATUS, mTrackIndex ) ;

        for ( auto it : nowPlayInfo.names_ )
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d clearing name %s because track is changed ", __FUNCTION__, __LINE__, it.second.c_str() ) ; 

        nowPlayInfo.names_.clear();
        
        if ( cdType_ !=  eNoCDTextCDDA )
        {

            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d clearing nowPlayInfo and starting timer %d  ", __FUNCTION__, __LINE__ , timerId_nowPlaying_) ;
            
            RemoteCDPlayControls::TimerExpired = false; 

          //  cancelTimer ( timerId_nowPlaying_ ) ; 

            timerId_nowPlaying_  = startTimer ( T_NOWPLAYING )  ;
            
             LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d After clearing nowPlayInfo and starting timerid  %d  ", __FUNCTION__, __LINE__ , timerId_nowPlaying_) ;


            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sent active track <%d, %d> received from player to the client", __FUNCTION__, __LINE__, folderNumber, trackNumber ) ;
        }
        else
        {
            string NowplayingName = "Track" ;
            NowplayingName += mTrackIndex;
            nowPlayingName namePair = make_pair ( eFileName , NowplayingName ) ;
            nowPlayInfo. names_. push_back ( namePair ) ;
            PRESEVENT_PUBLISH ( cdNowPlayingInfo, EVENT_PLAYCONTROL_NOWPLAYING_STATUS, nowPlayInfo ) ;
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sending NowPlaying Info in case of Track with CDDA_NO_Text ", __FUNCTION__, __LINE__ ) ;
            
        }
    }
    else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d active track <%d, %d> received from player is same as the one we have currently ", __FUNCTION__, __LINE__, folderNumber, trackNumber ) ;
}

// timer callback notified after T_fast is expired
void RemoteCDPlayControls::timerEvent ( int timerId )
{
    // check if it is our timerId
    if ( timerId == timerId_ )
    {
        // increase the speed and set to the player if we are in forward or reverse modes else we have nothing to do upon T_Fast expiry seems user has released fast fwd/ rev soon
        int action_forward = ( playAction_ == eForwardSpeed1 )? eForwardSpeed2 : -1 ;
        int action_reverse = ( playAction_ == eReverseSpeed1 )? eReverseSpeed2 : -1 ;

        if ( action_forward != -1 )    
        {
            mediaplayback_types::NAV_SetOperationMode_Rq_enum playerAction = static_cast < mediaplayback_types::NAV_SetOperationMode_Rq_enum::Literal > ( action_forward ) ;

            player_-> getNAV_SetOperationMode_Rq_enumAttribute ().setValueAsync ( playerAction, bind ( &RemoteCDPlayControls::plfCallback2, this, _1, _2 ) ) ;
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sent playerAction %d to the player", __FUNCTION__, __LINE__, playerAction ) ;
        }
        else
        {
           LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d we are not processing playAction for reverse :%d", __FUNCTION__, __LINE__, action_forward ) ; 
        }
        
        if ( action_reverse != -1 )    
        {
            mediaplayback_types::NAV_SetOperationMode_Rq_enum playerAction = static_cast < mediaplayback_types::NAV_SetOperationMode_Rq_enum::Literal > ( action_reverse ) ;

            player_-> getNAV_SetOperationMode_Rq_enumAttribute ().setValueAsync ( playerAction, bind ( &RemoteCDPlayControls::plfCallback2, this, _1, _2 ) ) ;
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sent playerAction %d to the player", __FUNCTION__, __LINE__, playerAction ) ;
        }
        else    
        {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d we are not processing playAction for reverse : %d ", __FUNCTION__, __LINE__, action_reverse ) ;
        }
    }
    
    if ( timerId == timerId_nowPlaying_ )
    {
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d timer expired for nowplaying data  < timer Id : %d > ", __FUNCTION__, __LINE__, timerId  ) ;
        PRESEVENT_PUBLISH ( cdNowPlayingInfo, EVENT_PLAYCONTROL_NOWPLAYING_STATUS, nowPlayInfo ) ;
         LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sending NowPlaying data to mediapres < timer Id : %d > ", __FUNCTION__, __LINE__, timerId  ) ;
         //bool sessionStatus = true ; 
        // PRESEVENT_PUBLISH ( eventrequestQueueCD , REQ_CLEAR_QUEUE_CD , sessionStatus );
         RemoteCDPlayControls::TimerExpired = true ; 
        //LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d Sending NowPlaying data [ FileName : %s  ]", __FUNCTION__, __LINE__ , ( nowPlayInfo.names_ [ eFileName ] ) ) ;
    }
}

/*****   utilities/ helpers   *****/

// init members
void RemoteCDPlayControls::init ()
{
    // playcontrol related
    numberOfTracks_ = 0 ;
    trackPlayTime_  = { 0, 0 } ;
    activeTrack_    = { -1, -1 } ;
    playAction_     = eNoAction ;
    playContexts_   = {  { eShuffle, eOff },  { eRepeat, eOff }, { eScan, eOff }  } ;

}

// subscribes to the player on the signals we are interested in for play controls functionality
void RemoteCDPlayControls::subscribeSignals ( bool subscribe )
{
    static uint32_t signals5, signals6, signals9 ;
    if ( subscribe )
    {
        signals5 = SUBSCRIBE ( player_, getACU_Send_Signals_5Attribute (). getChangedEvent (), &RemoteCDPlayControls::ACUSignals5, _1 ) ;
        signals6 = SUBSCRIBE ( player_, getACU_Send_Signals_6Attribute (). getChangedEvent (), &RemoteCDPlayControls::ACUSignals6, _1 ) ;
        signals9 = SUBSCRIBE ( player_, getACU_SendSignals_9Attribute (). getChangedEvent (), &RemoteCDPlayControls::ACUSignals9, _1 ) ;
            
        subscribed_ = true ;
    }
    else
    {
        player_-> getACU_Send_Signals_5Attribute (). getChangedEvent (). unsubscribe ( signals5 ) ;
        player_-> getACU_Send_Signals_6Attribute (). getChangedEvent (). unsubscribe ( signals6 ) ;
        player_-> getACU_SendSignals_9Attribute (). getChangedEvent (). unsubscribe ( signals9 ) ;

        subscribed_ = false ;
    }

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d platform signals/ notifications %ssubscribed", __FUNCTION__, __LINE__, ( subscribe )? "" : "un" ) ;
}

void RemoteCDPlayControls::processNumberOfTracks ( uint16_t numberOfTracks )
{
    
    // value changed for numberOfTracks from player so update our variables and publish the same to client
    numberOfTracks_ = static_cast < uint64_t > ( numberOfTracks ) ;

    PRESEVENT_PUBLISH ( numberOfTracksStatus, EVENT_PLAYCONTROL_NUMBER_TRACKS_STATUS, ( numberOfTracks_ ) ) ;
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sent numberOfTracks %lu received from player to the client", __FUNCTION__, __LINE__, numberOfTracks_ ) ;


}

void RemoteCDPlayControls::processPlayContext ( CDPlayContext response )
{

            // value changed for play context in player so update it and notify our client about same
            
        PRESEVENT_PUBLISH ( playContextStatus, EVENT_PLAYCONTROL_CONTEXT_STATUS, response ) ;
            
        if ( response.first == eShuffle ) 
        {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d shuffle  : %d", __FUNCTION__, __LINE__,  response. second ) ;
        }
        else
        {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d repeat  : %d", __FUNCTION__, __LINE__,  response. second ) ;
        }
           
    
   
}

void RemoteCDPlayControls::processPlayAction ( int action )
{
   
        playAction_ = static_cast < eCDPlayActions > ( action ) ;
        
        // notify clients on the playAction update
        PRESEVENT_PUBLISH ( playActionStatus, EVENT_PLAYCONTROL_ACTION_STATUS, playAction_ ) ;
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d playAction %d published to client", __FUNCTION__, __LINE__, playAction_ ) ;
}

void RemoteCDPlayControls::processPlayTime ( uint16_t playTime, uint16_t totalTime )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d trackTime <%d,%d>", __FUNCTION__, __LINE__, playTime, totalTime ) ;
   // if ( ( trackPlayTime_. first != playTime ) || ( trackPlayTime_. second != totalTime ) )
   // {
        trackPlayTime_ = make_pair ( playTime, totalTime ) ;
        
        // notify clients on the playAction update
        PRESEVENT_PUBLISH ( playtrackTime, EVENT_PLAYCONTROL_TRACKTIME_STATUS, trackPlayTime_ ) ;
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d trackTime <%d,%d> published to client", __FUNCTION__, __LINE__, trackPlayTime_. first , trackPlayTime_. second ) ;
  //  }
  //  else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d playTime <%d %d> received from player is same as the one we have currently ", __FUNCTION__, __LINE__, playTime, totalTime ) ;
}

// calls to send data/ values to player

void RemoteCDPlayControls::setContextToPlayer ( CDPlayContext context )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__) ;
    CommonAPI::CallStatus callStatus ;
    
    int value = static_cast < int > (context. second ) ;
    if ( player_-> isAvailable () )
    {
        if ( context. first == eShuffle )
        {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sending Shuffle request to CD Player %d", __FUNCTION__, __LINE__, value ) ;
            mediaplayback_types::NAV_CDSetShuffle_Rq_enum playerShuffle = static_cast < mediaplayback_types::NAV_CDSetShuffle_Rq_enum::Literal > ( value ) ;

            player_-> NAV_CDSetShuffle_Rq_method ( playerShuffle, callStatus ) ;
        }
        else if ( context. first == eRepeat  )
        {
            LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d sending Repeat request to CD Player", __FUNCTION__, __LINE__, value ) ;
            mediaplayback_types::NAV_CDSetRepeat_Rq_enum playerRepeat   = static_cast < mediaplayback_types::NAV_CDSetRepeat_Rq_enum::Literal > ( value ) ;

            player_-> NAV_CDSetRepeat_Rq_method ( playerRepeat, callStatus ) ;
        }
    }
    else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d could not set play context to player proxy not available", __FUNCTION__, __LINE__ ) ;
}

void RemoteCDPlayControls::setPlayFolderToPlayer ( short folderNumber )
{
    if ( player_-> isAvailable () )
    {
       short unsigned int num = 1 ;
        // player is available so nullfiy other attributes & their master common to this signal and request for getFolderName along with its master set properly
        CommonAPI::CallStatus callStatus ;
        
        // now set the interested ones for playFolder
        player_-> getDsp_ItemIndex_RqAttribute ().        setValueAsync ( 1 , bind ( &RemoteCDPlayControls::plfCallback2, this, _1, _2 ) ) ;
       player_-> getDsp_FolderNumber3_RqAttribute ().    setValueAsync ( folderNumber, bind ( &RemoteCDPlayControls::plfCallback2, this, _1, _2 ) ) ;
        player_-> getDsp_PlayFrstTrInFldr_RqAttribute (). setValueAsync ( folderNumber  , bind ( &RemoteCDPlayControls::plfCallback2, this, _1, _2 ) ) ;
        
        mediaplayback_types::Dsp_AudioSourceSel3_Rq_enum source = mediaplayback_types::Dsp_AudioSourceSel3_Rq_enum::En_CD ;
        // below is our interested master signal
        player_-> Dsp_AudioSourceSel3_Rq_method ( source, callStatus ) ;

        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d setPlayFolder done with %d to player", __FUNCTION__, __LINE__, folderNumber ) ;
    }
    else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d could not set play folder to player proxy not available", __FUNCTION__, __LINE__ ) ;
}

void RemoteCDPlayControls::setTrackToPlayer ( eCDPlayDirection direction, CDPlayItemNumber trackNumber )
{
    if ( player_-> isAvailable () )
    {
        // check if it is current track we have to play
        if ( direction == eCurrent )    setTrackToPlayer ( ( trackNumber. first << 16 ) | ( trackNumber. second ) ) ;
        // else if it is skip track request check for the directoin and set the value to player it would know the current track so only direction is good enough
        else if ( direction == ePrev || direction == eNext )    skipTrackToPlayer ( direction ) ;
        
        else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d invalid params for playItem from client currently check direction param %d", __FUNCTION__, __LINE__, direction ) ;
    }
    else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d could not set play folder to player proxy not available", __FUNCTION__, __LINE__ ) ;
}

void RemoteCDPlayControls::setTrackToPlayer ( uint32_t trackNumber )
{
    // player is available so nullfiy other attributes & their master common to this signal and request for getFolderName along with its master set properly
    CommonAPI::CallStatus callStatus ;

    // nullify other unrelated attributes of this CAN signal
    player_-> getDsp_FolderNumber_RqAttribute ().   setValueAsync ( 0xFFFF , bind ( &RemoteCDPlayControls::plfCallback2, this, _1, _2 ) ) ;
    player_-> getDsp_ItemNameLength_RqAttribute (). setValueAsync ( 0, bind ( &RemoteCDPlayControls::plfCallback1, this, _1, _2 ) ) ;
    player_-> getDsp_CutItem_Rq_enumAttribute ().   setValueAsync ( mediaplayback_types::Dsp_CutItem_Rq_enum::Literal::En_Inactive, bind ( &RemoteCDPlayControls::plfCallback3, this, _1, _2 ) ) ;
    // their/ other master signal with inactive
   player_-> Dsp_GetCDTOCDData_Rq_method ( mediaplayback_types::Dsp_GetCDTOCDData_Rq_enum::Literal::En_Inactive, callStatus ) ;
    
    // now set the interested ones for getFolderName
    player_-> getDsp_SourceSetTrack_RqAttribute (). setValueAsync ( trackNumber, bind ( &RemoteCDPlayControls::plfCallback2, this, _1, _2 ) ) ;
    
    mediaplayback_types::Dsp_AudioSourceSel_Rq_enum source = mediaplayback_types::Dsp_AudioSourceSel_Rq_enum::Literal::En_CD ;
    // below is our interested master signal
    player_-> Dsp_AudioSourceSel_Rq_method ( source, callStatus ) ;

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d setTrack done with %d to player", __FUNCTION__, __LINE__, trackNumber ) ;
}

void RemoteCDPlayControls::skipTrackToPlayer ( eCDPlayDirection direction )
{
    CommonAPI::CallStatus status ;
    mediaplayback_types::HMI_SkipTrack_Rq_enum playerSkipTrack = ( direction == ePrev )? mediaplayback_types::HMI_SkipTrack_Rq_enum::Literal::En_Decrement : mediaplayback_types::HMI_SkipTrack_Rq_enum::Literal::En_Increment ;

    player_-> HMI_SkipTrack_Rq_method ( playerSkipTrack, status ) ;

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d direction %s track sent to player status %d", __FUNCTION__, __LINE__, ( direction == eNext )? "Next" : "Previous", status ) ;
}

void RemoteCDPlayControls::plfCallback1 ( const CommonAPI::CallStatus& status, uint8_t  plfValue )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful plfValue %lu", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", plfValue ) ;
}

void RemoteCDPlayControls::plfCallback2 ( const CommonAPI::CallStatus& status, uint32_t plfValue )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful plfValue %d", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", plfValue ) ;
}

void RemoteCDPlayControls::plfCallback3 ( const CommonAPI::CallStatus& status, uint32_t plfValue )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful plfValue %u", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", plfValue ) ;
}

void RemoteCDPlayControls::plfCallback4 ( const CommonAPI::CallStatus& status, mediaplayback_types::NAV_SetOperationMode_Rq_enum plfValue )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d callStatus %s successful operationMode plfValue %d", __FUNCTION__, __LINE__, ( status == CommonAPI::CallStatus::SUCCESS )? "" : "not", plfValue ) ;
}

// destructor
RemoteCDPlayControls::~RemoteCDPlayControls ()
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__ ) ;
    // unsubscribe to platform signals to stop getting signals/ notifications from player
    if ( subscribed_ )    subscribeSignals ( false ) ;
}
