#include "RemoteCDCache.hpp"

// constructors
RemoteCDCache::RemoteCDCache () : builderEnabled_ ( false )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d builderEnabled_ %d", __FUNCTION__, __LINE__, builderEnabled_ ) ;
    init () ;
}

RemoteCDCache::RemoteCDCache ( bool enable ) : builderEnabled_ ( enable )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d builderEnabled_ %d", __FUNCTION__, __LINE__, builderEnabled_ ) ;
	init () ;
}

void RemoteCDCache::init ()
{
    // subscribe for cdStatus notification from RemoteCDManager upon eject of disc we have to clear the data
    PRESEVENT_SUBSCRIBE ( cdType, EVENT_CD_TYPE, &RemoteCDCache::onCDType, _1 ) ;
    PRESEVENT_SUBSCRIBE ( cdStatus, EVENT_CD_STATUS, &RemoteCDCache::onCDStatus, _1 ) ;
    PRESEVENT_SUBSCRIBE ( cdError,  EVENT_CD_ERROR,  &RemoteCDCache::onCDError,  _1 ) ;

    // subscribe to the dataUpdate calls to get the data requested & cache the respective data received
    PRESEVENT_SUBSCRIBE ( folderDataUpdate, EVENT_FOLDER_DATA_UPDATE, &RemoteCDCache::onFolderDataUpdate, _1, _2 ) ;
    PRESEVENT_SUBSCRIBE ( tocDataUpdate,    EVENT_TOC_DATA_UPDATE,    &RemoteCDCache::onTOCDataUpdate, _1 ) ;

    // if cachebuilder is enabled instantiate it with config params of maxItemsPerRequest & maxItemNameLength
    if ( builderEnabled_ )    cacheBuilder_ = make_shared < RemoteCDCacheBuilder > ( 20, 20 ) ;
	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__ ) ;
}

void RemoteCDCache::onCDError ( CDError cdError )
{
    bool error = ( ( cdError. first != eNoError ) || ( cdError. second != eNoHWError ) ) ;

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d error %d", __FUNCTION__, __LINE__, error ) ;

    // clear all the data upon any of these eject operation status informed by player
    if ( error )    clear ( static_cast < eCacheType > ( eCDTableData | eMP3Data ) ) ;
}

void RemoteCDCache::onCDType ( eCDType cdType )
{
    cdType_ = cdType ;
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d type %d", __FUNCTION__, __LINE__, cdType_ ) ;
}

// CDDA does not have CD text in it so we have to generate the generic names for the tracks under it
void RemoteCDCache::populateCDDACache ()
{
    // create the root folder for the CDDA
    Folder root = make_shared < FolderData > ( 0, -1, "" ) ;
    folders_. insert ( make_pair ( 0, root ) ) ;

    for ( auto &content : CDTable_ )
    {
        Item item = make_shared < ItemData > ( ) ;

        string name = "Track " ;
        name += to_string ( content. first ) ;

        item-> setIndex ( content. first ) ;
        item-> setName ( name ) ;
        item-> setType ( eFile ) ;
        item-> setNumber ( make_pair ( 0, content. first ) ) ;

        root-> addItem ( item ) ;
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d inserted record <%d,%s>", __FUNCTION__, __LINE__, item-> getIndex (), item-> getName (). c_str () ) ;
    }
    
    root -> setTotalItemCount ( static_cast <unsigned short > ( CDTable_. size () ) );
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d TotalTracks in CDDA disc %d", __FUNCTION__, __LINE__, CDTable_. size () ) ;
}

// cd status notified by RemoteCDManager
void RemoteCDCache::onCDStatus ( eCDStatus status )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d status %d", __FUNCTION__, __LINE__, status ) ;
    switch ( status )
    {
        case eInvalidStatus :
        case ePrepareEject :
        case eEjecting :
        case eRemoveDisc :
            
            // clear all the data upon any of these eject operation status informed by player
            clear ( static_cast < eCacheType > ( eCDTableData | eMP3Data ) ) ;
            break ;
        default :
            // ignore others
            break ;
    }
}

// updates Table of contents data of CDDA into cache
void RemoteCDCache::onTOCDataUpdate ( CDTableofContents &contents )
{
    CDTable_ = contents ;
    
    if ( cdType_ == eNoCDTextCDDA )    populateCDDACache () ;
}

// updates 
void RemoteCDCache::onFolderDataUpdate ( Folder folder , bool valid )
{
    // update this folder first in the cache
   // bool success = valid && updateFolder ( folder ) ;
   // if ( success )
  //  {
        
        if ( folders_. size () < MAX_FOLDERS_IN_CACHE )    folders_ [ folder->getNumber() ] = folder ;
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d updating <folderNumber : %d, folderName : %s>", __FUNCTION__, __LINE__, folder-> getNumber (), folder->getName().c_str() ) ;
        
        // iterate through the children of this folder and create an entry for folder number along with its parent, this is the only time we maybe aware of the parent as parent would not be sent directly
        /*
        for ( auto &item : folder-> getItemsList () )
        {   
            if ( item-> getType () == eFolder )
            {
                // first create the entry for this in cache and update the parent folderNumber in this record
                Folder data = make_shared < FolderData > ( item-> getNumber (). first, folder-> getNumber (), item-> getName () ) ;
                
                // insert into cache if not reached the max limit, based on the performance and memory usage increase/ decrease the MAX_FOLDERS_IN_CACHE
                if ( folders_. size () < MAX_FOLDERS_IN_CACHE )    folders_. insert ( make_pair ( item-> getNumber (). first, data ) ) ;

                else    success = false ;
            }
        }*/

        // publish event to the clients interested in cache updates
        PRESEVENT_PUBLISH ( cacheUpdate, EVENT_CACHE_FOLDER_UPDATE, folders_ [ folder-> getNumber () ] , true ) ;
        LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d cacheUpdate published for %d ", __FUNCTION__, __LINE__, folder-> getNumber ()) ;
 //   }
  //  else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d max cache entries reached will not cache this data", __FUNCTION__, __LINE__ ) ;
}

bool RemoteCDCache::updateFolder ( Folder folder )
{
    bool success = true ;

    // check if record exists in the cache if so update it else insert a new record
    if ( folders_. find ( folder-> getNumber () ) != folders_. end () )
    {
        Folder data = folders_ [ folder-> getNumber () ] ;

        // update rest of the contents of the folder arrived now into the record present in the cache
        data-> setTotalItems ( folder-> getTotalItems () ) ;
        for ( auto &item : folder-> getItemsList () )    data-> addItem ( item ) ;
    }
    else
    {
        // we would come here only for root folder, or when the max entries for cache is reached
        // new record go ahead and insert into cache if not reached the max limit, based on the performance and memory usage increase/ decrease the MAX_FOLDERS_IN_CACHE
        if ( folders_. size () < MAX_FOLDERS_IN_CACHE )    folders_. insert ( make_pair ( folder-> getNumber (), folder ) ) ;

        else    success = false ;
    }

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d folderNumber %d success %d", __FUNCTION__, __LINE__, folder-> getNumber (), success ) ;
    return ( success ) ;  
}

bool RemoteCDCache::isAvailable ( short folderNumber )
{
    bool yes = folders_. find ( folderNumber ) != folders_.end () ;

    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d folderNumber %d yes %d", __FUNCTION__, __LINE__, folderNumber, yes ) ;
    
    return yes ;
}

bool RemoteCDCache::isAvailable ( short folderNumber, int start, int numItems )
{
    bool yes = false ;

    if ( folders_. find ( folderNumber ) != folders_.end () )
    {
        Folder data = folders_ [ folderNumber ] ;

        // check if the range we are interested is cached, or may be HMI asks for more range than what is available in the folder in CD
        yes = ( data-> getItemsList (). size () >= static_cast < unsigned int > ( start + numItems ) ) || ( data-> getTotalItems () == data-> getItemsList (). size () ) ;

        if ( ! yes )    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "cache has fewer entries than requested so get data from player" ) ;
    }
    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d folderNumber %d start %d numItems %d available %d", __FUNCTION__, __LINE__, folderNumber, start, numItems, yes ) ;

    return yes ;
}

// sends the CD table of contents data to the client, return true if we have valid entries available in cache, else false
bool RemoteCDCache::getData ( CDTableofContents& contents )
{
    contents = CDTable_ ;

    LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d CDTable NumEntries %d", __FUNCTION__, __LINE__, CDTable_ ) ;

    return ( CDTable_. size () > 0 ) ;
}

void RemoteCDCache::clear ( eCacheType type )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d clearing cahce entries type 0x%x", __FUNCTION__, __LINE__, type ) ;

    if ( ( type & eCDTableData ) && ! ( CDTable_.empty () )  )  CDTable_. clear () ;
    if (  ( type & eMP3Data ) && ! ( folders_.empty ()  ) )  folders_. clear () ;
    
}

// destructor
RemoteCDCache::~RemoteCDCache ()
{
	LOG_ERROR ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d CDTable NumEntries %d", __FUNCTION__, __LINE__, CDTable_ ) ;
	
	// clear all the data upon destruction
	clear ( static_cast < eCacheType > ( eCDTableData | eMP3Data ) ) ;
}
