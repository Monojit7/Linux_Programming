
#include <RemoteCDCacheBuilder.hpp>

// class members instantiation
condition_variable    RemoteCDCacheBuilder::cv_ ;
mutex                 RemoteCDCacheBuilder::sync_ ;
queue < Folder >      RemoteCDCacheBuilder::events_ ;

// constructors - default one all config params are routed to default values as per SPSS
RemoteCDCacheBuilder::RemoteCDCacheBuilder () : maxItems_ ( MAX_ITEM_COUNT_PER_REQUEST ), maxItemNameLength_ ( MAX_ITEM_NAME_LENGTH ), done_ ( false )
{
	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d maxItems_ %d maxItemNameLength_ %d done_ %d", __FUNCTION__, __LINE__, maxItems_, maxItemNameLength_, done_ ) ;
//	init () ;
}

// constructors - all config params are customized as per the parameters by the client
RemoteCDCacheBuilder::RemoteCDCacheBuilder ( int maxItemsPerRequest, int maxItemNameLength ) : maxItems_ ( maxItemsPerRequest ), maxItemNameLength_ ( maxItemNameLength ), done_ ( false )
{
	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d maxItems_ %d maxItemNameLength_ %d done_ %d", __FUNCTION__, __LINE__, maxItems_, maxItemNameLength_, done_ ) ;
	//init () ;
}

void RemoteCDCacheBuilder::init ()
{
    // subscribe for cdStatus notification from RemoteCDManager upon eject of disc we have to clear the data
    PRESEVENT_SUBSCRIBE ( cdStatus, EVENT_CD_STATUS, &RemoteCDCacheBuilder::onCDStatus, _1 ) ;
    PRESEVENT_SUBSCRIBE ( cdType, EVENT_CD_TYPE, &RemoteCDCacheBuilder::onCDType, _1 ) ;

	// subscribe to the dataUpdate calls to get the data requested & continue recursive data acquistion
    PRESEVENT_SUBSCRIBE ( cacheUpdate, EVENT_CACHE_FOLDER_UPDATE, &RemoteCDCacheBuilder::onCacheUpdate, _1, _2 ) ;
    // start the builder thread
    builder_ = thread ( bind ( &RemoteCDCacheBuilder::start, this ) ) ;

	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d maxItems_ %d maxItemNameLength_ %d done_ %d", __FUNCTION__, __LINE__, maxItems_, maxItemNameLength_, done_ ) ;
}

// cd status notified by RemoteCDManager
void RemoteCDCacheBuilder::onCDType ( eCDType cdType )
{
    cdType_ = cdType ;
}

// cd status notified by RemoteCDManager
void RemoteCDCacheBuilder::onCDStatus ( eCDStatus status )
{
    // start with root folder, folderNumber would be 0 for root folder as per SPSS
    if ( status == eLoaded )
    {
	    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d status %d type %d", __FUNCTION__, __LINE__, status, cdType_ ) ;
        if ( cdType_ != eNoCDTextCDDA )        RemoteCDManager::getInstance ()-> requestFolder ( ROOT_FOLDER_NUMBER, 0, MAX_ITEM_COUNT_PER_REQUEST ) ; 

        else    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d CDDA disc with no text in it so cache component will generate generic tracks", __FUNCTION__, __LINE__ ) ;
    }
	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d status %d type %d", __FUNCTION__, __LINE__, status, cdType_ ) ;
}

// notification from cache sending the data and a flag indicating whether it could cache it or not
void RemoteCDCacheBuilder::onCacheUpdate ( Folder data, bool success )
{
    // push the event into thread handler so as the event publisher would process other events in queue and w edo not hold for the cache builder
    ScopedLock lock ( sync_ ) ;
    
	// if cache update is failed for some reason maybe due to maxCacheEntries reached, the builder thread has to be stopped done_ flag will do this job for us
    if ( success )
    {
        addEvent ( data ) ;
        cv_. notify_one () ;
    }
    else    done_ = true ;  // cache is full so the builder task is done and cannot go on further

	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d maxItems_ %d maxItemNameLength_ %d done_ %d", __FUNCTION__, __LINE__, maxItems_, maxItemNameLength_, done_ ) ;
}

void RemoteCDCacheBuilder::start ( void )
{
    while ( ! done_ )
    {
        ScopedLock lock ( sync_ ) ;
        while ( getEvents (). empty () )    cv_. wait ( lock ) ;
        
        processData ( getEvent () ) ;
        removeEvent () ;
    }
}

void RemoteCDCacheBuilder::processData ( Folder cached )
{
	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d currentList %d TotalItems %d", __FUNCTION__, __LINE__, cached-> getItemsList (). size (), cached-> getTotalItems () ) ;
    // check if we have all the items of the folder else request for next set of items of this folder first
    if ( cached-> getItemsList (). size () < cached-> getTotalItems () )    RemoteCDManager::getInstance ()-> requestFolder ( cached-> getNumber (), cached-> getItemsList (). size (), maxItems_ ) ;
    else
    {
        // we have all the items of this folder go ahead with requesting for the data of its children
        for ( auto &item : cached-> getItemsList () )
        {   
            if ( item-> getType () == eFolder )    RemoteCDManager::getInstance ()-> requestFolder ( item-> getNumber (). first, 0, maxItems_ ) ;
        }
    }
}

RemoteCDCacheBuilder::~RemoteCDCacheBuilder ()
{
	LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d", __FUNCTION__, __LINE__ ) ;
	done_ = true ;
}

