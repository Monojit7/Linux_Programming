#include <RemoteCDConfig.hpp>


CRemoteCDConfig::CRemoteCDConfig () : mExtCDPresent_ ( false ), mWarningPopup_ ( false ), mEOLReceived_ ( false ), Result_ ( 0 )
{
   LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d ", __FUNCTION__, __LINE__ ) ;
 //  buf_byte = new unsigned char [ 1 ] ; 
   this->setExtCDPresentWithWarningPopup ();
}

CRemoteCDConfig::~CRemoteCDConfig ()
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d ", __FUNCTION__, __LINE__ ) ;
//    delete buf_byte;
    
}

void CRemoteCDConfig::setExtCDPresentWithWarningPopup ()
{
      LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d ", __FUNCTION__, __LINE__ ) ;
      
      if ( setEOLData ( ADJ_E2P_DIAG_EOL_DE00_AUDIO_EXT_CD_ID , ADJ_E2P_DIAG_EOL_DE00_AUDIO_EXT_CD_SIZE ) )
      {
        
          
          unsigned char ResultCDPresent = this -> getEOLData ();
          
          // Based on Ford comment on assembla id : 1986 the default values are External CD Present with Warning EXT_CD_PRESENT_NO_WARNING_popup
          
          mExtCDPresent_ = true;
          mWarningPopup_ = true;
          
         
          
          
          switch ( ResultCDPresent )
          {
              case EXT_CD_PRESENT_NO_WARNING_POPUP :
              {
                  LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <cdpresent : %d, Warningpopup : %d> ", __FUNCTION__, __LINE__ , mExtCDPresent_ , mWarningPopup_) ;
                  //mExtCDPresent_ = true ;
                  mWarningPopup_ = false ;
                  
                   this -> setEOLData ( EXT_CD_PRESENT_NO_WARNING_POPUP );
                  break;
              }
              case EXT_CD_PRESENT_WARNING_POPUP :
              {
                  LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <cdpresent : %d, Warningpopup : %d> ", __FUNCTION__, __LINE__ , mExtCDPresent_ , mWarningPopup_) ;
                  //mExtCDPresent_ = true ;
                  //mWarningPopup_ = true ;
                  this -> setEOLData ( EXT_CD_PRESENT_WARNING_POPUP );
                  break;
              }
              case EXD_CD_PRESENT_DISABLED :
              {
                  LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <cdpresent : %d, Warningpopup : %d> ", __FUNCTION__, __LINE__ , mExtCDPresent_ , mWarningPopup_) ;
                  mExtCDPresent_ = false;
                  mWarningPopup_ = false;
                  
                  this -> setEOLData ( EXD_CD_PRESENT_DISABLED );
                  
                  break;
              }
              case EXT_CD_PRESENT_NO_CONFIGURED :
              {
                  LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d <cdpresent : %d, Warningpopup : %d> ", __FUNCTION__, __LINE__ , mExtCDPresent_ , mWarningPopup_) ;
                  //mExtCDPresent_ = true;
                  //mWarningPopup_ = true;
                  this -> setEOLData ( EXT_CD_PRESENT_NO_CONFIGURED );
                  break;
              }
          }
          
          
          
          
      }
      
      
}






void CRemoteCDConfig::ProcessEjectRequest ()
{
      LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d ", __FUNCTION__, __LINE__ ) ;
}


bool  CRemoteCDConfig::setEOLData ( unsigned long sysSetID , unsigned long sysIDSize )
{
    LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d ", __FUNCTION__, __LINE__ ) ;
    
    if ( ! mEOLReceived_ )
       {
    
           char id[4];
           char buf_byte[1]="";

           id[0] = (sysSetID >> 24) & 0xFF;
           id[1] = (sysSetID >> 16) & 0xFF;
           id[2] = (sysSetID >> 8) & 0xFF;
           id[3] = sysSetID & 0xFF;

           pclKeyReadData(PCL_LDBID_EOL, (const char *)id, PCL_STD_USER_NO, PCL_STD_SEAT_NO, (unsigned char*)buf_byte, sysIDSize);
    
           Result_  = buf_byte [ 0 ];
    
           mEOLReceived_ = true;
    
          LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d < EOL Received : %d , result : %d>", __FUNCTION__, __LINE__ , mEOLReceived_  , Result_ ) ;
    
    }
    else 
      {
          LOG_INFO ( LOG_CONTEXT_RCD_PLUGIN, "%s:%d < EOL Received : %d , result : %d>", __FUNCTION__, __LINE__ , mEOLReceived_  , Result_ ) ;
      }
    
    
    return mEOLReceived_ ;
     
     
}
