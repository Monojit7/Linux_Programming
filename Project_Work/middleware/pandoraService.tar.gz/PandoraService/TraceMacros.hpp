#ifndef TRACEMACROS_HPP_
#define TRACEMACROS_HPP_

#include "api/sys/tracesrv/pf/trace/src/private/HBTraceMacros.hpp"
#include "api/sys/tracesrv/pf/trace/src/CTraceThread.hpp"
#include "api/sys/tracesrv/pf/trace/src/CHBNullTracePersistence.hpp"
#endif /*IOCTRACEMACROS_HPP_*/
