#include "CPandoraProtocolCommands.hpp"

class CPandoraProtocolCommands
{

public:
	CPandoraProtocolCommands();

	virtual void startSession() = 0;

};
